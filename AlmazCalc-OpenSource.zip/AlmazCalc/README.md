# AlmazCalc — Open-Source Scientific Calculator (Android)

An advanced, 100% offline, zero-permission open-source scientific calculator for Android built with **Kotlin**, **Jetpack Compose**, and **Material 3**.

## Features
- **Casio 991-Inspired Scientific Keypad**: Full SHIFT / ALPHA dual-layer keypad with circular D-Pad navigation, natural expression display, and instant live preview.
- **Advanced Math Engine**:
  - Trigonometry & Inverse / Hyperbolic functions with `DEG` / `RAD` / `GRAD` modes
  - Logarithms (`log`, `ln`, `logₓy`), Powers & Roots (`√`, `∛`, `ʸ√x`, `x²`, `x³`, `xʸ`, `10ˣ`, `eˣ`)
  - Numerical Calculus: Definite Integrals `∫(expr, a, b)`, Derivatives `d/dx(expr, x0)`, Summation `Σ`, Product `Π`, and Root Solver (`SOLVE`)
  - Combinatorics & Number Theory: `x!`, `nPr`, `nCr`, `GCD`, `LCM`, Prime Factorization (`FACT`), `mod`, `Ceil`, `Floor`
  - Exact Fraction Toggle (`S⇔D`), Engineering Notation (`ENG`), Degrees-Minutes-Seconds (`° ' "`)
  - Memory Registers (`A–F`, `X`, `Y`, `M`, `Ans`, `PreAns`)
- **5 Built-in Skins + Material You**:
  1. **AMOLED Pro** (Pure black body, crisp mint LCD, amber SHIFT, lavender ALPHA, orange AC/DEL)
  2. **Pure AMOLED** (100% true black screen & keypad for OLED displays)
  3. **Slate Classic** (Classic grey body, olive LCD screen, yellow SHIFT, crimson ALPHA)
  4. **Modern Light** (Clean light casing, deep slate screen, cobalt blue SHIFT, magenta ALPHA)
  5. **Material You** (Dynamic Android 12+ wallpaper colors with dark/light support)
- **Built-in Unit Converter (12 Categories)** & **Scientific Constants Library** (Physics & Chemistry)
- **Calculation History** with tap-to-reuse and copy
- **Bilingual UI**: Full Arabic (`العربية`) and English support
- **Privacy First**: 100% offline, zero ads, zero tracking, zero permissions

## How to Build the APK Automatically (No PC Needed!)
1. Create a new repository on **GitHub** (e.g., `AlmazCalc`).
2. Extract this ZIP and upload all files (including the `.github` folder) to the repository.
3. Open the **Actions** tab on GitHub — the **Build Android APK** workflow will start automatically.
4. Wait ~2–3 minutes until the build finishes with a green checkmark.
5. Click the completed workflow run and scroll to **Artifacts** to download **`AlmazCalc-APK`** (contains ready-to-install `.apk` files).

---
Made with love by Mostafa Almaz 🤍
