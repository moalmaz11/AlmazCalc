# AlmazCalc ProGuard Rules
-keepattributes *Annotation*
