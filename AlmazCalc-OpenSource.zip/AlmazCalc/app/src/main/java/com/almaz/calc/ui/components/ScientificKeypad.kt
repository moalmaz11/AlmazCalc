package com.almaz.calc.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Backspace
import androidx.compose.material.icons.rounded.Functions
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.almaz.calc.ui.theme.CalculatorSkinPalette
import com.almaz.calc.viewmodel.CalculatorUiState
import com.almaz.calc.viewmodel.CalculatorViewModel

@Composable
fun QuickToolbar(
    state: CalculatorUiState,
    palette: CalculatorSkinPalette,
    onOpenMenu: () -> Unit,
    onOpenSkins: () -> Unit,
    onOpenConstants: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenConverter: () -> Unit,
    onOpenHistory: () -> Unit,
    onCycleAngle: () -> Unit,
    modifier: Modifier = Modifier
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            modifier = modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ToolbarIconButton(Icons.Rounded.Menu, "Menu", palette, onOpenMenu)
            ToolbarIconButton(Icons.Rounded.Palette, "Skins", palette, onOpenSkins)
            ToolbarIconButton(Icons.Rounded.Functions, "Constants", palette, onOpenConstants)
            ToolbarIconButton(Icons.Rounded.Settings, "Settings", palette, onOpenSettings)
            ToolbarIconButton(Icons.Rounded.SwapHoriz, "Converter", palette, onOpenConverter)
            ToolbarIconButton(Icons.Rounded.History, "History", palette, onOpenHistory)

            Spacer(modifier = Modifier.weight(1f))

            Box(
                modifier = Modifier
                    .height(34.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(palette.toolbarIconBg)
                    .clickable(onClick = onCycleAngle)
                    .padding(horizontal = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = state.settings.angleUnit.label,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = palette.toolbarIconTint
                )
            }
        }
    }
}

@Composable
private fun ToolbarIconButton(
    icon: ImageVector,
    contentDescription: String,
    palette: CalculatorSkinPalette,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(palette.toolbarIconBg)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = palette.toolbarIconTint,
            modifier = Modifier.size(19.dp)
        )
    }
}

@Composable
fun ScientificKeypad(
    state: CalculatorUiState,
    palette: CalculatorSkinPalette,
    viewModel: CalculatorViewModel,
    onOpenConverter: () -> Unit,
    onOpenConstants: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenVariables: () -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val clipboard = LocalClipboardManager.current

    fun feedback() {
        if (state.settings.hapticEnabled) {
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(
            modifier = modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            // ================= TOP CONTROL BLOCK (SHIFT/ALPHA + D-PAD + MODE/2ND) =================
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(2.05f),
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left 2 columns
                Column(
                    modifier = Modifier
                        .weight(2f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        CalcKey(
                            label = "SHIFT",
                            bg = palette.shiftKeyBg,
                            fg = palette.shiftKeyText,
                            palette = palette,
                            fontSize = 11.sp,
                            highlighted = state.isShift,
                            modifier = Modifier.weight(1f)
                        ) { feedback(); viewModel.toggleShift() }

                        CalcKey(
                            label = "ALPHA",
                            bg = palette.alphaKeyBg,
                            fg = palette.alphaKeyText,
                            palette = palette,
                            fontSize = 11.sp,
                            highlighted = state.isAlpha,
                            modifier = Modifier.weight(1f)
                        ) { feedback(); viewModel.toggleAlpha() }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        CalcKey(
                            label = "CALC",
                            shiftHint = "SOLVE",
                            alphaHint = "=",
                            bg = palette.sciKeyBg,
                            fg = palette.sciKeyText,
                            palette = palette,
                            fontSize = 11.sp,
                            modifier = Modifier.weight(1f)
                        ) {
                            feedback()
                            when {
                                state.isShift -> viewModel.solveCurrentExpression()
                                state.isAlpha -> viewModel.insertToken("=")
                                else -> viewModel.evaluateExpression()
                            }
                        }

                        CalcKey(
                            label = "∫dx",
                            shiftHint = "d/dx",
                            alphaHint = ",",
                            bg = palette.sciKeyBg,
                            fg = palette.sciKeyText,
                            palette = palette,
                            fontSize = 12.sp,
                            modifier = Modifier.weight(1f)
                        ) {
                            feedback()
                            when {
                                state.isShift -> viewModel.insertToken("d/dx(,)", cursorOffsetFromEnd = 2)
                                state.isAlpha -> viewModel.insertToken(",")
                                else -> viewModel.insertToken("∫(,,)", cursorOffsetFromEnd = 3)
                            }
                        }
                    }
                }

                // Center Circular 4-Way D-Pad
                CalculatorDPad(
                    palette = palette,
                    onUp = { feedback(); viewModel.navigateHistoryUp() },
                    onDown = { feedback(); viewModel.navigateHistoryDown() },
                    onLeft = { feedback(); viewModel.moveCursorLeft() },
                    onRight = { feedback(); viewModel.moveCursorRight() },
                    onCenter = { feedback(); viewModel.evaluateExpression() },
                    modifier = Modifier
                        .weight(1.9f)
                        .fillMaxHeight()
                )

                // Right 2 columns
                Column(
                    modifier = Modifier
                        .weight(2f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        CalcKey(
                            label = "MODE",
                            bg = palette.sciKeyBg,
                            fg = palette.sciKeyText,
                            palette = palette,
                            fontSize = 11.sp,
                            modifier = Modifier.weight(1f)
                        ) { feedback(); onOpenConverter() }

                        CalcKey(
                            label = "2nd",
                            bg = palette.sciKeyBg,
                            fg = palette.sciKeyText,
                            palette = palette,
                            fontSize = 11.sp,
                            highlighted = state.isSecond,
                            modifier = Modifier.weight(1f)
                        ) { feedback(); viewModel.toggleSecond() }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        CalcKey(
                            label = "x⁻¹",
                            shiftHint = "x!",
                            alphaHint = "abs",
                            bg = palette.sciKeyBg,
                            fg = palette.sciKeyText,
                            palette = palette,
                            fontSize = 12.sp,
                            modifier = Modifier.weight(1f)
                        ) {
                            feedback()
                            when {
                                state.isShift -> viewModel.insertToken("!")
                                state.isAlpha -> viewModel.insertToken("abs(", cursorOffsetFromEnd = 0)
                                else -> viewModel.insertToken("⁻¹")
                            }
                        }

                        CalcKey(
                            label = "logₓy",
                            shiftHint = "Σ",
                            alphaHint = "Π",
                            bg = palette.sciKeyBg,
                            fg = palette.sciKeyText,
                            palette = palette,
                            fontSize = 11.sp,
                            modifier = Modifier.weight(1f)
                        ) {
                            feedback()
                            when {
                                state.isShift -> viewModel.insertToken("Σ(,,)", cursorOffsetFromEnd = 3)
                                state.isAlpha -> viewModel.insertToken("Π(,,)", cursorOffsetFromEnd = 3)
                                else -> viewModel.insertToken("logb(,)", cursorOffsetFromEnd = 2)
                            }
                        }
                    }
                }
            }

            // ================= SCIENTIFIC 6-COLUMN GRID (3 ROWS) =================
            // Row 1: a/b, √, x², xʸ, log, ln
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.05f),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                CalcKey(
                    label = "a/b",
                    shiftHint = "S⇔D",
                    alphaHint = "mod",
                    bg = palette.sciKeyBg,
                    fg = palette.sciKeyText,
                    palette = palette,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    when {
                        state.isShift -> viewModel.toggleFractionFormat()
                        state.isAlpha -> viewModel.insertToken("mod(,)", cursorOffsetFromEnd = 2)
                        else -> viewModel.insertToken("÷")
                    }
                }

                CalcKey(
                    label = "√□",
                    shiftHint = "∛□",
                    alphaHint = "mod",
                    bg = palette.sciKeyBg,
                    fg = palette.sciKeyText,
                    palette = palette,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    when {
                        state.isShift -> viewModel.insertToken("∛(")
                        state.isAlpha -> viewModel.insertToken("mod(,)", cursorOffsetFromEnd = 2)
                        else -> viewModel.insertToken("√(")
                    }
                }

                CalcKey(
                    label = "x²",
                    shiftHint = "x³",
                    bg = palette.sciKeyBg,
                    fg = palette.sciKeyText,
                    palette = palette,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    if (state.isShift) viewModel.insertToken("³") else viewModel.insertToken("²")
                }

                CalcKey(
                    label = "xʸ",
                    shiftHint = "ʸ√x",
                    bg = palette.sciKeyBg,
                    fg = palette.sciKeyText,
                    palette = palette,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    if (state.isShift) viewModel.insertToken("nthroot(,)", cursorOffsetFromEnd = 2)
                    else viewModel.insertToken("^")
                }

                CalcKey(
                    label = "log",
                    shiftHint = "10ˣ",
                    bg = palette.sciKeyBg,
                    fg = palette.sciKeyText,
                    palette = palette,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    if (state.isShift) viewModel.insertToken("10^(") else viewModel.insertToken("log(")
                }

                CalcKey(
                    label = "ln",
                    shiftHint = "eˣ",
                    alphaHint = "e",
                    bg = palette.sciKeyBg,
                    fg = palette.sciKeyText,
                    palette = palette,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    when {
                        state.isShift -> viewModel.insertToken("e^(")
                        state.isAlpha -> viewModel.insertToken("e")
                        else -> viewModel.insertToken("ln(")
                    }
                }
            }

            // Row 2: (-), °'", hyp, sin, cos, tan
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.05f),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                CalcKey(
                    label = "(−)",
                    shiftHint = "abs",
                    alphaHint = "A",
                    bg = palette.sciKeyBg,
                    fg = palette.sciKeyText,
                    palette = palette,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    when {
                        state.isStoPending || state.isRclPending || state.isAlpha -> viewModel.handleVariableKey("A")
                        state.isShift -> viewModel.insertToken("abs(")
                        else -> viewModel.insertToken("−")
                    }
                }

                CalcKey(
                    label = "° ' \"",
                    shiftHint = "FACT",
                    alphaHint = "B",
                    bg = palette.sciKeyBg,
                    fg = palette.sciKeyText,
                    palette = palette,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    when {
                        state.isStoPending || state.isRclPending || state.isAlpha -> viewModel.handleVariableKey("B")
                        state.isShift -> viewModel.applyPrimeFactorization()
                        else -> viewModel.toggleDmsFormat()
                    }
                }

                CalcKey(
                    label = "hyp",
                    shiftHint = "|x|",
                    alphaHint = "C",
                    bg = palette.sciKeyBg,
                    fg = palette.sciKeyText,
                    palette = palette,
                    highlighted = state.isHyp,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    when {
                        state.isStoPending || state.isRclPending || state.isAlpha -> viewModel.handleVariableKey("C")
                        state.isShift -> viewModel.insertToken("abs(")
                        else -> viewModel.toggleHyp()
                    }
                }

                CalcKey(
                    label = if (state.isHyp) "sinh" else "sin",
                    shiftHint = if (state.isHyp) "sinh⁻¹" else "sin⁻¹",
                    alphaHint = "D",
                    bg = palette.sciKeyBg,
                    fg = palette.sciKeyText,
                    palette = palette,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    when {
                        state.isStoPending || state.isRclPending || state.isAlpha -> viewModel.handleVariableKey("D")
                        state.isShift && state.isHyp -> viewModel.insertToken("sinh⁻¹(")
                        state.isShift -> viewModel.insertToken("sin⁻¹(")
                        state.isHyp -> viewModel.insertToken("sinh(")
                        else -> viewModel.insertToken("sin(")
                    }
                }

                CalcKey(
                    label = if (state.isHyp) "cosh" else "cos",
                    shiftHint = if (state.isHyp) "cosh⁻¹" else "cos⁻¹",
                    alphaHint = "E",
                    bg = palette.sciKeyBg,
                    fg = palette.sciKeyText,
                    palette = palette,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    when {
                        state.isStoPending || state.isRclPending || state.isAlpha -> viewModel.handleVariableKey("E")
                        state.isShift && state.isHyp -> viewModel.insertToken("cosh⁻¹(")
                        state.isShift -> viewModel.insertToken("cos⁻¹(")
                        state.isHyp -> viewModel.insertToken("cosh(")
                        else -> viewModel.insertToken("cos(")
                    }
                }

                CalcKey(
                    label = if (state.isHyp) "tanh" else "tan",
                    shiftHint = if (state.isHyp) "tanh⁻¹" else "tan⁻¹",
                    alphaHint = "F",
                    bg = palette.sciKeyBg,
                    fg = palette.sciKeyText,
                    palette = palette,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    when {
                        state.isStoPending || state.isRclPending || state.isAlpha -> viewModel.handleVariableKey("F")
                        state.isShift && state.isHyp -> viewModel.insertToken("tanh⁻¹(")
                        state.isShift -> viewModel.insertToken("tan⁻¹(")
                        state.isHyp -> viewModel.insertToken("tanh(")
                        else -> viewModel.insertToken("tan(")
                    }
                }
            }

            // Row 3: RCL, ENG, (, ), S⇔D, M+
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.05f),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                CalcKey(
                    label = "RCL",
                    shiftHint = "STO",
                    alphaHint = "VARS",
                    bg = palette.sciKeyBg,
                    fg = palette.sciKeyText,
                    palette = palette,
                    highlighted = state.isRclPending || state.isStoPending,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    when {
                        state.isShift -> viewModel.startSto()
                        state.isAlpha -> onOpenVariables()
                        else -> viewModel.startRcl()
                    }
                }

                CalcKey(
                    label = "ENG",
                    shiftHint = "cot",
                    alphaHint = "cot⁻¹",
                    bg = palette.sciKeyBg,
                    fg = palette.sciKeyText,
                    palette = palette,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    when {
                        state.isShift -> viewModel.insertToken("cot(")
                        state.isAlpha -> viewModel.insertToken("cot⁻¹(")
                        else -> viewModel.toggleEngineeringFormat()
                    }
                }

                CalcKey(
                    label = "(",
                    shiftHint = "%",
                    alphaHint = "cot⁻¹",
                    bg = palette.sciKeyBg,
                    fg = palette.sciKeyText,
                    palette = palette,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    when {
                        state.isShift -> viewModel.insertToken("%")
                        state.isAlpha -> viewModel.insertToken("cot⁻¹(")
                        else -> viewModel.insertToken("(")
                    }
                }

                CalcKey(
                    label = ")",
                    shiftHint = ",",
                    alphaHint = "X",
                    bg = palette.sciKeyBg,
                    fg = palette.sciKeyText,
                    palette = palette,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    when {
                        state.isStoPending || state.isRclPending || state.isAlpha -> viewModel.handleVariableKey("X")
                        state.isShift -> viewModel.insertToken(",")
                        else -> viewModel.insertToken(")")
                    }
                }

                CalcKey(
                    label = "S⇔D",
                    shiftHint = "FRAC",
                    alphaHint = "Y",
                    bg = palette.sciKeyBg,
                    fg = palette.sciKeyText,
                    palette = palette,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    when {
                        state.isStoPending || state.isRclPending || state.isAlpha -> viewModel.handleVariableKey("Y")
                        else -> viewModel.toggleFractionFormat()
                    }
                }

                CalcKey(
                    label = "M+",
                    shiftHint = "M−",
                    alphaHint = "M",
                    bg = palette.sciKeyBg,
                    fg = palette.sciKeyText,
                    palette = palette,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    when {
                        state.isStoPending || state.isRclPending || state.isAlpha -> viewModel.handleVariableKey("M")
                        state.isShift -> viewModel.memoryAdd(subtract = true)
                        else -> viewModel.memoryAdd(subtract = false)
                    }
                }
            }

            Spacer(modifier = Modifier.height(2.dp))

            // ================= NUMERIC & OPERATOR 5-COLUMN GRID (4 ROWS) =================
            // Row 1: 7, 8, 9, DEL, AC
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.22f),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                CalcKey(
                    label = "7",
                    shiftHint = "CONST",
                    bg = palette.numKeyBg,
                    fg = palette.numKeyText,
                    palette = palette,
                    fontSize = 20.sp,
                    cornerRadius = 11.dp,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    if (state.isShift) { viewModel.toggleShift(); onOpenConstants() }
                    else viewModel.insertToken("7")
                }

                CalcKey(
                    label = "8",
                    shiftHint = "CONV",
                    bg = palette.numKeyBg,
                    fg = palette.numKeyText,
                    palette = palette,
                    fontSize = 20.sp,
                    cornerRadius = 11.dp,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    if (state.isShift) { viewModel.toggleShift(); onOpenConverter() }
                    else viewModel.insertToken("8")
                }

                CalcKey(
                    label = "9",
                    shiftHint = "CLRv",
                    bg = palette.numKeyBg,
                    fg = palette.numKeyText,
                    palette = palette,
                    fontSize = 20.sp,
                    cornerRadius = 11.dp,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    if (state.isShift) viewModel.clearVariables() else viewModel.insertToken("9")
                }

                CalcIconKey(
                    icon = Icons.Rounded.Backspace,
                    contentDescription = "Delete",
                    bg = palette.delAcKeyBg,
                    fg = palette.delAcKeyText,
                    palette = palette,
                    cornerRadius = 11.dp,
                    modifier = Modifier.weight(1f)
                ) { feedback(); viewModel.backspace() }

                CalcKey(
                    label = "AC",
                    shiftHint = "CLR ALL",
                    bg = palette.delAcKeyBg,
                    fg = palette.delAcKeyText,
                    palette = palette,
                    fontSize = 18.sp,
                    cornerRadius = 11.dp,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    if (state.isShift) viewModel.clearAll() else viewModel.clearExpression()
                }
            }

            // Row 2: 4, 5, 6, ×, ÷
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.22f),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                CalcKey(
                    label = "4",
                    shiftHint = "min",
                    bg = palette.numKeyBg,
                    fg = palette.numKeyText,
                    palette = palette,
                    fontSize = 20.sp,
                    cornerRadius = 11.dp,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    if (state.isShift) viewModel.insertToken("min(,)", cursorOffsetFromEnd = 2)
                    else viewModel.insertToken("4")
                }

                CalcKey(
                    label = "5",
                    shiftHint = "max",
                    bg = palette.numKeyBg,
                    fg = palette.numKeyText,
                    palette = palette,
                    fontSize = 20.sp,
                    cornerRadius = 11.dp,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    if (state.isShift) viewModel.insertToken("max(,)", cursorOffsetFromEnd = 2)
                    else viewModel.insertToken("5")
                }

                CalcKey(
                    label = "6",
                    shiftHint = "VARS",
                    bg = palette.numKeyBg,
                    fg = palette.numKeyText,
                    palette = palette,
                    fontSize = 20.sp,
                    cornerRadius = 11.dp,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    if (state.isShift) { viewModel.toggleShift(); onOpenVariables() }
                    else viewModel.insertToken("6")
                }

                CalcKey(
                    label = "×",
                    shiftHint = "nPr",
                    alphaHint = "GCD",
                    bg = palette.opKeyBg,
                    fg = palette.opKeyText,
                    palette = palette,
                    fontSize = 21.sp,
                    cornerRadius = 11.dp,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    when {
                        state.isShift -> viewModel.insertToken("nPr(,)", cursorOffsetFromEnd = 2)
                        state.isAlpha -> viewModel.insertToken("gcd(,)", cursorOffsetFromEnd = 2)
                        else -> viewModel.insertToken("×")
                    }
                }

                CalcKey(
                    label = "÷",
                    shiftHint = "nCr",
                    alphaHint = "LCM",
                    bg = palette.opKeyBg,
                    fg = palette.opKeyText,
                    palette = palette,
                    fontSize = 21.sp,
                    cornerRadius = 11.dp,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    when {
                        state.isShift -> viewModel.insertToken("nCr(,)", cursorOffsetFromEnd = 2)
                        state.isAlpha -> viewModel.insertToken("lcm(,)", cursorOffsetFromEnd = 2)
                        else -> viewModel.insertToken("÷")
                    }
                }
            }

            // Row 3: 1, 2, 3, +, −
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.22f),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                CalcKey(
                    label = "1",
                    shiftHint = "SOLVE",
                    bg = palette.numKeyBg,
                    fg = palette.numKeyText,
                    palette = palette,
                    fontSize = 20.sp,
                    cornerRadius = 11.dp,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    if (state.isShift) viewModel.solveCurrentExpression()
                    else viewModel.insertToken("1")
                }

                CalcKey(
                    label = "2",
                    shiftHint = "d/dx",
                    bg = palette.numKeyBg,
                    fg = palette.numKeyText,
                    palette = palette,
                    fontSize = 20.sp,
                    cornerRadius = 11.dp,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    if (state.isShift) viewModel.insertToken("d/dx(,)", cursorOffsetFromEnd = 2)
                    else viewModel.insertToken("2")
                }

                CalcKey(
                    label = "3",
                    shiftHint = "∫dx",
                    bg = palette.numKeyBg,
                    fg = palette.numKeyText,
                    palette = palette,
                    fontSize = 20.sp,
                    cornerRadius = 11.dp,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    if (state.isShift) viewModel.insertToken("∫(,,)", cursorOffsetFromEnd = 3)
                    else viewModel.insertToken("3")
                }

                CalcKey(
                    label = "+",
                    shiftHint = "Pol",
                    alphaHint = "Ceil",
                    bg = palette.opKeyBg,
                    fg = palette.opKeyText,
                    palette = palette,
                    fontSize = 21.sp,
                    cornerRadius = 11.dp,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    when {
                        state.isShift -> viewModel.insertToken("pol(,)", cursorOffsetFromEnd = 2)
                        state.isAlpha -> viewModel.insertToken("ceil(")
                        else -> viewModel.insertToken("+")
                    }
                }

                CalcKey(
                    label = "−",
                    shiftHint = "Rec",
                    alphaHint = "Floor",
                    bg = palette.opKeyBg,
                    fg = palette.opKeyText,
                    palette = palette,
                    fontSize = 21.sp,
                    cornerRadius = 11.dp,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    when {
                        state.isShift -> viewModel.insertToken("rec(,)", cursorOffsetFromEnd = 2)
                        state.isAlpha -> viewModel.insertToken("floor(")
                        else -> viewModel.insertToken("−")
                    }
                }
            }

            // Row 4: 0, ., Exp, Ans, =
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.22f),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                CalcKey(
                    label = "0",
                    shiftHint = "COPY",
                    alphaHint = "PASTE",
                    bg = palette.numKeyBg,
                    fg = palette.numKeyText,
                    palette = palette,
                    fontSize = 20.sp,
                    cornerRadius = 11.dp,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    when {
                        state.isShift -> {
                            val toCopy = state.finalResult.ifEmpty { state.liveResult.ifEmpty { state.expression } }
                            if (toCopy.isNotEmpty()) {
                                clipboard.setText(AnnotatedString(toCopy))
                                viewModel.showToast("Copied: $toCopy")
                            }
                            viewModel.toggleShift()
                        }
                        state.isAlpha -> {
                            val pasted = clipboard.getText()?.text ?: ""
                            if (pasted.isNotEmpty()) viewModel.insertToken(pasted)
                            else viewModel.toggleAlpha()
                        }
                        else -> viewModel.insertToken("0")
                    }
                }

                CalcKey(
                    label = ".",
                    shiftHint = "Ran#",
                    alphaHint = "RanInt",
                    bg = palette.numKeyBg,
                    fg = palette.numKeyText,
                    palette = palette,
                    fontSize = 22.sp,
                    cornerRadius = 11.dp,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    when {
                        state.isShift -> viewModel.insertToken("rand()")
                        state.isAlpha -> viewModel.insertToken("randint(,)", cursorOffsetFromEnd = 2)
                        else -> viewModel.insertToken(".")
                    }
                }

                CalcKey(
                    label = "Exp",
                    shiftHint = "π",
                    alphaHint = "e",
                    bg = palette.numKeyBg,
                    fg = palette.numKeyText,
                    palette = palette,
                    fontSize = 17.sp,
                    cornerRadius = 11.dp,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    when {
                        state.isShift -> viewModel.insertToken("π")
                        state.isAlpha -> viewModel.insertToken("e")
                        else -> viewModel.insertToken("×10^")
                    }
                }

                CalcKey(
                    label = "Ans",
                    shiftHint = "PreAns",
                    bg = palette.opKeyBg,
                    fg = palette.opKeyText,
                    palette = palette,
                    fontSize = 16.sp,
                    cornerRadius = 11.dp,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    if (state.isShift) viewModel.insertToken("PreAns") else viewModel.insertToken("Ans")
                }

                CalcKey(
                    label = "=",
                    shiftHint = "History",
                    bg = palette.equalsKeyBg,
                    fg = palette.equalsKeyText,
                    palette = palette,
                    fontSize = 22.sp,
                    cornerRadius = 11.dp,
                    modifier = Modifier.weight(1f)
                ) {
                    feedback()
                    if (state.isShift) { viewModel.toggleShift(); onOpenHistory() }
                    else viewModel.evaluateExpression()
                }
            }
        }
    }
}

@Composable
private fun CalcKey(
    label: String,
    bg: Color,
    fg: Color,
    palette: CalculatorSkinPalette,
    modifier: Modifier = Modifier,
    shiftHint: String = "",
    alphaHint: String = "",
    fontSize: TextUnit = 13.sp,
    cornerRadius: Dp = 8.dp,
    highlighted: Boolean = false,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier.fillMaxHeight(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Dual Shift / Alpha hint label above key (exact Casio 991EX look)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(13.dp)
                .padding(horizontal = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = shiftHint,
                fontSize = 8.5.sp,
                fontWeight = FontWeight.Bold,
                color = palette.shiftHintColor,
                maxLines = 1,
                overflow = TextOverflow.Clip
            )
            if (alphaHint.isNotEmpty()) {
                Text(
                    text = alphaHint,
                    fontSize = 8.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = palette.alphaHintColor,
                    maxLines = 1,
                    overflow = TextOverflow.Clip
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(cornerRadius))
                .background(bg)
                .then(
                    if (highlighted) {
                        Modifier.border(1.8.dp, palette.accentColor, RoundedCornerShape(cornerRadius))
                    } else {
                        Modifier
                    }
                )
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                fontSize = fontSize,
                fontWeight = FontWeight.SemiBold,
                color = fg,
                maxLines = 1,
                overflow = TextOverflow.Clip
            )
        }
    }
}

@Composable
private fun CalcIconKey(
    icon: ImageVector,
    contentDescription: String,
    bg: Color,
    fg: Color,
    palette: CalculatorSkinPalette,
    modifier: Modifier = Modifier,
    shiftHint: String = "",
    cornerRadius: Dp = 11.dp,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier.fillMaxHeight(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(13.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            if (shiftHint.isNotEmpty()) {
                Text(
                    text = shiftHint,
                    fontSize = 8.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = palette.shiftHintColor
                )
            }
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(cornerRadius))
                .background(bg)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = fg,
                modifier = Modifier.size(21.dp)
            )
        }
    }
}

@Composable
private fun CalculatorDPad(
    palette: CalculatorSkinPalette,
    onUp: () -> Unit,
    onDown: () -> Unit,
    onLeft: () -> Unit,
    onRight: () -> Unit,
    onCenter: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(palette.dpadOuterBg),
        contentAlignment = Alignment.Center
    ) {
        // Up
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth(0.55f)
                .fillMaxHeight(0.36f)
                .clickable(onClick = onUp),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.KeyboardArrowUp,
                contentDescription = "Up",
                tint = palette.dpadIconTint,
                modifier = Modifier.size(18.dp)
            )
        }
        // Down
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(0.55f)
                .fillMaxHeight(0.36f)
                .clickable(onClick = onDown),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.KeyboardArrowDown,
                contentDescription = "Down",
                tint = palette.dpadIconTint,
                modifier = Modifier.size(18.dp)
            )
        }
        // Left
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .fillMaxWidth(0.36f)
                .fillMaxHeight(0.58f)
                .clickable(onClick = onLeft),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.KeyboardArrowLeft,
                contentDescription = "Left",
                tint = palette.dpadIconTint,
                modifier = Modifier.size(18.dp)
            )
        }
        // Right
        Box(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .fillMaxWidth(0.36f)
                .fillMaxHeight(0.58f)
                .clickable(onClick = onRight),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.KeyboardArrowRight,
                contentDescription = "Right",
                tint = palette.dpadIconTint,
                modifier = Modifier.size(18.dp)
            )
        }
        // Center button
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(palette.dpadInnerBg)
                .clickable(onClick = onCenter)
        )
    }
}
