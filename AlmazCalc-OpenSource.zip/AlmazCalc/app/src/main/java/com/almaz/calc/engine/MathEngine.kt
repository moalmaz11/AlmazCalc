package com.almaz.calc.engine

import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.*
import kotlin.random.Random

enum class AngleUnit(val label: String) {
    DEG("DEG"),
    RAD("RAD"),
    GRAD("GRAD");

    fun next(): AngleUnit = when (this) {
        DEG -> RAD
        RAD -> GRAD
        GRAD -> DEG
    }
}

sealed class EvalResult {
    data class Success(val value: Double) : EvalResult()
    data class Error(val message: String) : EvalResult()
}

object MathEngine {

    private fun toRadians(x: Double, unit: AngleUnit): Double = when (unit) {
        AngleUnit.DEG -> Math.toRadians(x)
        AngleUnit.RAD -> x
        AngleUnit.GRAD -> x * PI / 200.0
    }

    private fun fromRadians(rad: Double, unit: AngleUnit): Double = when (unit) {
        AngleUnit.DEG -> Math.toDegrees(rad)
        AngleUnit.RAD -> rad
        AngleUnit.GRAD -> rad * 200.0 / PI
    }

    fun evaluate(
        rawExpression: String,
        angleUnit: AngleUnit = AngleUnit.DEG,
        variables: Map<String, Double> = emptyMap()
    ): EvalResult {
        val cleaned = rawExpression.trim()
        if (cleaned.isEmpty()) return EvalResult.Error("Empty")

        return try {
            val normalized = preprocess(cleaned)
            val parser = Parser(normalized, angleUnit, variables)
            val value = parser.parseExpression()
            parser.skipWhitespace()
            if (parser.pos < parser.input.length) {
                return EvalResult.Error("Syntax Error")
            }
            if (value.isNaN()) {
                EvalResult.Error("Math Error")
            } else if (value.isInfinite()) {
                EvalResult.Error("Overflow / ∞")
            } else {
                val snapped = if (abs(value) < 1e-13) 0.0 else value
                EvalResult.Success(snapped)
            }
        } catch (e: Exception) {
            EvalResult.Error(e.message ?: "Syntax Error")
        }
    }

    private fun preprocess(expr: String): String {
        var s = expr
            .replace("×10^", "E")
            .replace("×", "*")
            .replace("÷", "/")
            .replace("−", "-")
            .replace("–", "-")
            .replace("π", "pi")
            .replace("²", "^2")
            .replace("³", "^3")
            .replace("⁻¹", "^(-1)")
            .replace("∛", "cbrt")
            .replace("√", "sqrt")
            .replace("∫", "integ")
            .replace("Σ", "sum")
            .replace("Π", "prod")
            .replace("d/dx", "deriv")
            .replace("sin⁻¹", "asin")
            .replace("cos⁻¹", "acos")
            .replace("tan⁻¹", "atan")
            .replace("cot⁻¹", "acot")
            .replace("sinh⁻¹", "asinh")
            .replace("cosh⁻¹", "acosh")
            .replace("tanh⁻¹", "atanh")
            .replace(" ", "")

        // Auto-close unmatched opening parentheses for smoother live evaluation
        val opens = s.count { it == '(' }
        val closes = s.count { it == ')' }
        if (opens > closes) {
            s += ")".repeat(opens - closes)
        }
        return s
    }

    // Split top-level comma-separated arguments inside function calls
    private fun splitTopLevelArgs(argStr: String): List<String> {
        val result = mutableListOf<String>()
        var depth = 0
        var start = 0
        for (i in argStr.indices) {
            when (argStr[i]) {
                '(' -> depth++
                ')' -> depth--
                ',' -> if (depth == 0) {
                    result.add(argStr.substring(start, i))
                    start = i + 1
                }
            }
        }
        result.add(argStr.substring(start))
        return result
    }

    private fun evalWithX(
        exprStr: String,
        xVal: Double,
        angleUnit: AngleUnit,
        variables: Map<String, Double>
    ): Double {
        val vars = variables.toMutableMap()
        vars["x"] = xVal
        vars["X"] = xVal
        return when (val r = evaluate(exprStr, angleUnit, vars)) {
            is EvalResult.Success -> r.value
            is EvalResult.Error -> throw IllegalArgumentException(r.message)
        }
    }

    private fun numericalDerivative(
        exprStr: String,
        x0: Double,
        angleUnit: AngleUnit,
        variables: Map<String, Double>
    ): Double {
        val h = max(1e-5, abs(x0) * 1e-5)
        val f1 = evalWithX(exprStr, x0 - 2 * h, angleUnit, variables)
        val f2 = evalWithX(exprStr, x0 - h, angleUnit, variables)
        val f3 = evalWithX(exprStr, x0 + h, angleUnit, variables)
        val f4 = evalWithX(exprStr, x0 + 2 * h, angleUnit, variables)
        return (f1 - 8.0 * f2 + 8.0 * f3 - f4) / (12.0 * h)
    }

    private fun numericalIntegral(
        exprStr: String,
        a: Double,
        b: Double,
        angleUnit: AngleUnit,
        variables: Map<String, Double>
    ): Double {
        if (a == b) return 0.0
        val n = 200
        val h = (b - a) / n
        var sum = evalWithX(exprStr, a, angleUnit, variables) +
            evalWithX(exprStr, b, angleUnit, variables)
        for (i in 1 until n) {
            val coeff = if (i % 2 == 0) 2.0 else 4.0
            sum += coeff * evalWithX(exprStr, a + i * h, angleUnit, variables)
        }
        return sum * h / 3.0
    }

    private fun summation(
        exprStr: String,
        start: Int,
        end: Int,
        angleUnit: AngleUnit,
        variables: Map<String, Double>
    ): Double {
        if (end - start > 10_000) throw IllegalArgumentException("Range too large")
        var total = 0.0
        for (k in start..end) {
            total += evalWithX(exprStr, k.toDouble(), angleUnit, variables)
        }
        return total
    }

    private fun product(
        exprStr: String,
        start: Int,
        end: Int,
        angleUnit: AngleUnit,
        variables: Map<String, Double>
    ): Double {
        if (end - start > 10_000) throw IllegalArgumentException("Range too large")
        var total = 1.0
        for (k in start..end) {
            total *= evalWithX(exprStr, k.toDouble(), angleUnit, variables)
        }
        return total
    }

    fun solveEquation(
        rawExpr: String,
        initialGuess: Double = 1.0,
        angleUnit: AngleUnit = AngleUnit.DEG,
        variables: Map<String, Double> = emptyMap()
    ): EvalResult {
        val equationExpr = if (rawExpr.contains("=")) {
            val parts = rawExpr.split("=")
            if (parts.size != 2) return EvalResult.Error("Invalid Equation")
            "(${parts[0]})-(${parts[1]})"
        } else {
            rawExpr
        }

        val guesses = listOf(initialGuess, 0.0, 1.0, -1.0, 2.0, -2.0, 5.0, 10.0)
        for (startGuess in guesses) {
            var x = startGuess
            try {
                for (iter in 0 until 80) {
                    val fx = evalWithX(equationExpr, x, angleUnit, variables)
                    if (abs(fx) < 1e-10) {
                        val snapped = if (abs(x) < 1e-11) 0.0 else x
                        return EvalResult.Success(snapped)
                    }
                    val dfx = numericalDerivative(equationExpr, x, angleUnit, variables)
                    if (abs(dfx) < 1e-14 || dfx.isNaN() || dfx.isInfinite()) break
                    val nextX = x - fx / dfx
                    if (nextX.isNaN() || nextX.isInfinite()) break
                    if (abs(nextX - x) < 1e-11) {
                        val verify = evalWithX(equationExpr, nextX, angleUnit, variables)
                        if (abs(verify) < 1e-6) {
                            val snapped = if (abs(nextX) < 1e-11) 0.0 else nextX
                            return EvalResult.Success(snapped)
                        }
                    }
                    x = nextX
                }
            } catch (_: Exception) {
                // Try next starting guess
            }
        }
        return EvalResult.Error("No Real Root Found")
    }

    // Lanczos approximation of Gamma function for factorial of integers & reals
    fun factorial(n: Double): Double {
        if (n < 0.0 && n == floor(n)) throw IllegalArgumentException("Math Error")
        if (n == floor(n) && n >= 0.0 && n <= 170.0) {
            var res = 1.0
            for (i in 2..n.toInt()) res *= i
            return res
        }
        return gamma(n + 1.0)
    }

    private fun gamma(zInput: Double): Double {
        val g = 7.0
        val p = doubleArrayOf(
            0.99999999999980993,
            676.5203681218851,
            -1259.1392167224028,
            771.32342877765313,
            -176.61502916214059,
            12.507343278686905,
            -0.13857109526572012,
            9.9843695780195716e-6,
            1.5056327351493116e-7
        )
        return if (zInput < 0.5) {
            PI / (sin(PI * zInput) * gamma(1.0 - zInput))
        } else {
            val z = zInput - 1.0
            var x = p[0]
            for (i in 1 until p.size) {
                x += p[i] / (z + i)
            }
            val t = z + g + 0.5
            sqrt(2.0 * PI) * t.pow(z + 0.5) * exp(-t) * x
        }
    }

    fun nPr(n: Double, r: Double): Double {
        if (n < 0 || r < 0 || r > n || n != floor(n) || r != floor(r)) {
            throw IllegalArgumentException("Math Error")
        }
        var res = 1.0
        for (i in 0 until r.toInt()) {
            res *= (n - i)
        }
        return res
    }

    fun nCr(n: Double, r: Double): Double {
        if (n < 0 || r < 0 || r > n || n != floor(n) || r != floor(r)) {
            throw IllegalArgumentException("Math Error")
        }
        val k = min(r.toInt(), (n - r).toInt())
        var res = 1.0
        for (i in 1..k) {
            res = res * (n - k + i) / i
        }
        return res
    }

    fun gcd(aIn: Long, bIn: Long): Long {
        var a = abs(aIn)
        var b = abs(bIn)
        while (b != 0L) {
            val t = b
            b = a % b
            a = t
        }
        return a
    }

    fun lcm(aIn: Long, bIn: Long): Long {
        if (aIn == 0L || bIn == 0L) return 0L
        return abs(aIn / gcd(aIn, bIn) * bIn)
    }

    fun primeFactorize(value: Double): String {
        if (value != floor(value) || value < 2.0 || value > 1e12) {
            return formatDecimal(value, 10)
        }
        var n = value.toLong()
        val factors = mutableListOf<Pair<Long, Int>>()
        var d = 2L
        while (d * d <= n) {
            var count = 0
            while (n % d == 0L) {
                n /= d
                count++
            }
            if (count > 0) factors.add(d to count)
            d = if (d == 2L) 3L else d + 2L
        }
        if (n > 1L) factors.add(n to 1)
        return factors.joinToString(" × ") { (prime, exp) ->
            if (exp == 1) "$prime" else "$prime${toSuperscript(exp)}"
        }
    }

    fun toSuperscript(n: Int): String {
        val map = mapOf(
            '0' to '⁰', '1' to '¹', '2' to '²', '3' to '³', '4' to '⁴',
            '5' to '⁵', '6' to '⁶', '7' to '⁷', '8' to '⁸', '9' to '⁹', '-' to '⁻'
        )
        return n.toString().map { map[it] ?: it }.joinToString("")
    }

    fun toExactFraction(value: Double, maxDenom: Long = 10000L): String? {
        if (value.isNaN() || value.isInfinite()) return null
        if (abs(value - round(value)) < 1e-10) return null
        val sign = if (value < 0) "-" else ""
        val x = abs(value)
        var h1 = 1L
        var h2 = 0L
        var k1 = 0L
        var k2 = 1L
        var b = x
        for (i in 0 until 20) {
            val a = floor(b).toLong()
            val h = a * h1 + h2
            val k = a * k1 + k2
            if (k > maxDenom) break
            h2 = h1
            h1 = h
            k2 = k1
            k1 = k
            val diff = abs(x - h1.toDouble() / k1.toDouble())
            if (diff < 1e-9) {
                return if (k1 == 1L) null else "$sign$h1/$k1"
            }
            val frac = b - a
            if (frac < 1e-12) break
            b = 1.0 / frac
        }
        return if (k1 > 1L && abs(x - h1.toDouble() / k1.toDouble()) < 1e-7) {
            "$sign$h1/$k1"
        } else null
    }

    fun toEngineering(value: Double, precision: Int = 6): String {
        if (value == 0.0) return "0"
        val sign = if (value < 0) "-" else ""
        val absVal = abs(value)
        val exp3 = (floor(log10(absVal) / 3.0) * 3.0).toInt()
        val mantissa = absVal / 10.0.pow(exp3.toDouble())
        val formattedMantissa = formatDecimal(mantissa, min(precision, 8))
        return if (exp3 == 0) "$sign$formattedMantissa"
        else "$sign$formattedMantissa×10${toSuperscript(exp3)}"
    }

    fun toDms(value: Double): String {
        val sign = if (value < 0) "-" else ""
        val absVal = abs(value)
        val deg = floor(absVal).toInt()
        val minFloat = (absVal - deg) * 60.0
        val min = floor(minFloat).toInt()
        val sec = (minFloat - min) * 60.0
        val secStr = formatDecimal(sec, 2)
        return "$sign${deg}° ${min}' ${secStr}\""
    }

    fun formatDecimal(value: Double, precision: Int = 10): String {
        if (value.isNaN()) return "Error"
        if (value.isInfinite()) return if (value > 0) "∞" else "-∞"
        if (value == 0.0) return "0"

        val absVal = abs(value)
        if (absVal >= 1e12 || absVal < 1e-7) {
            val formatted = String.format(java.util.Locale.US, "%.${min(precision, 8)}E", value)
            val parts = formatted.split("E")
            val mantissa = parts[0].trimEnd('0').trimEnd('.')
            val exponent = parts[1].toInt()
            return "${mantissa}×10${toSuperscript(exponent)}"
        }

        val bd = BigDecimal.valueOf(value)
            .setScale(precision, RoundingMode.HALF_UP)
            .stripTrailingZeros()
        return bd.toPlainString()
    }

    private class Parser(
        val input: String,
        val angleUnit: AngleUnit,
        val variables: Map<String, Double>
    ) {
        var pos = 0

        fun skipWhitespace() {
            while (pos < input.length && input[pos].isWhitespace()) pos++
        }

        private fun peek(): Char? = if (pos < input.length) input[pos] else null

        private fun match(ch: Char): Boolean {
            skipWhitespace()
            if (pos < input.length && input[pos] == ch) {
                pos++
                return true
            }
            return false
        }

        fun parseExpression(): Double {
            var left = parseTerm()
            while (true) {
                skipWhitespace()
                left = when {
                    match('+') -> left + parseTerm()
                    match('-') -> left - parseTerm()
                    else -> return left
                }
            }
        }

        private fun parseTerm(): Double {
            var left = parsePower()
            while (true) {
                skipWhitespace()
                when {
                    match('*') -> left *= parsePower()
                    match('/') -> {
                        val right = parsePower()
                        if (right == 0.0) throw IllegalArgumentException("Division by Zero")
                        left /= right
                    }
                    // Implicit multiplication: e.g., 2pi, 3sin(30), (2+1)(3+1), 2(5)
                    startsImplicitFactor() -> left *= parsePower()
                    else -> return left
                }
            }
        }

        private fun startsImplicitFactor(): Boolean {
            val ch = peek() ?: return false
            return ch == '(' || ch.isLetter()
        }

        private fun parsePower(): Double {
            val base = parseUnary()
            skipWhitespace()
            return if (match('^')) {
                val exp = parsePower() // Right-associative
                base.pow(exp)
            } else {
                base
            }
        }

        private fun parseUnary(): Double {
            skipWhitespace()
            return when {
                match('+') -> parseUnary()
                match('-') -> -parseUnary()
                else -> parsePostfix()
            }
        }

        private fun parsePostfix(): Double {
            var value = parsePrimary()
            while (true) {
                skipWhitespace()
                value = when {
                    match('!') -> factorial(value)
                    match('%') -> value / 100.0
                    else -> return value
                }
            }
        }

        private fun parsePrimary(): Double {
            skipWhitespace()
            val ch = peek() ?: throw IllegalArgumentException("Syntax Error")

            // Parentheses
            if (match('(')) {
                val value = parseExpression()
                if (!match(')')) throw IllegalArgumentException("Missing ')'")
                return value
            }

            // Number literal (supports scientific notation 1.5E-3)
            if (ch.isDigit() || ch == '.') {
                return parseNumber()
            }

            // Identifier: Function or Constant or Variable
            if (ch.isLetter()) {
                return parseIdentifier()
            }

            throw IllegalArgumentException("Syntax Error")
        }

        private fun parseNumber(): Double {
            val start = pos
            var hasDot = false
            while (pos < input.length && (input[pos].isDigit() || input[pos] == '.')) {
                if (input[pos] == '.') {
                    if (hasDot) break
                    hasDot = true
                }
                pos++
            }
            // Scientific notation exponent E+10 / E-5 (only when followed by digit or +/- digit)
            if (pos < input.length && input[pos] == 'E') {
                val nextIdx = pos + 1
                if (nextIdx < input.length && (
                        input[nextIdx].isDigit() ||
                            ((input[nextIdx] == '+' || input[nextIdx] == '-') &&
                                nextIdx + 1 < input.length && input[nextIdx + 1].isDigit())
                        )
                ) {
                    pos++
                    if (input[pos] == '+' || input[pos] == '-') pos++
                    while (pos < input.length && input[pos].isDigit()) pos++
                }
            }
            return input.substring(start, pos).toDoubleOrNull()
                ?: throw IllegalArgumentException("Invalid Number")
        }

        private fun extractParenthesizedRaw(): String {
            if (!match('(')) throw IllegalArgumentException("Expected '('")
            val start = pos
            var depth = 1
            while (pos < input.length && depth > 0) {
                when (input[pos]) {
                    '(' -> depth++
                    ')' -> depth--
                }
                pos++
            }
            if (depth != 0) throw IllegalArgumentException("Missing ')'")
            return input.substring(start, pos - 1)
        }

        private fun parseArgList(): List<Double> {
            val raw = extractParenthesizedRaw()
            if (raw.isEmpty()) return emptyList()
            return splitTopLevelArgs(raw).map { arg ->
                when (val r = evaluate(arg, angleUnit, variables)) {
                    is EvalResult.Success -> r.value
                    is EvalResult.Error -> throw IllegalArgumentException(r.message)
                }
            }
        }

        private fun parseIdentifier(): Double {
            val start = pos
            while (pos < input.length && (input[pos].isLetterOrDigit() || input[pos] == '_')) {
                pos++
            }
            val name = input.substring(start, pos)
            val lower = name.lowercase()

            // Calculus / higher-order functions that take an expression as first argument
            if (lower in setOf("deriv", "integ", "sum", "prod", "solve")) {
                val raw = extractParenthesizedRaw()
                val args = splitTopLevelArgs(raw)
                return when (lower) {
                    "deriv" -> {
                        if (args.size < 2) throw IllegalArgumentException("deriv(expr, x0)")
                        val x0 = evalArg(args[1])
                        numericalDerivative(args[0], x0, angleUnit, variables)
                    }
                    "integ" -> {
                        if (args.size < 3) throw IllegalArgumentException("integ(expr, a, b)")
                        val a = evalArg(args[1])
                        val b = evalArg(args[2])
                        numericalIntegral(args[0], a, b, angleUnit, variables)
                    }
                    "sum" -> {
                        if (args.size < 3) throw IllegalArgumentException("sum(expr, start, end)")
                        val a = evalArg(args[1]).toInt()
                        val b = evalArg(args[2]).toInt()
                        summation(args[0], a, b, angleUnit, variables)
                    }
                    "prod" -> {
                        if (args.size < 3) throw IllegalArgumentException("prod(expr, start, end)")
                        val a = evalArg(args[1]).toInt()
                        val b = evalArg(args[2]).toInt()
                        product(args[0], a, b, angleUnit, variables)
                    }
                    "solve" -> {
                        val guess = if (args.size >= 2) evalArg(args[1]) else 1.0
                        when (val res = solveEquation(args[0], guess, angleUnit, variables)) {
                            is EvalResult.Success -> res.value
                            is EvalResult.Error -> throw IllegalArgumentException(res.message)
                        }
                    }
                    else -> throw IllegalArgumentException("Unknown function")
                }
            }

            // Functions with parenthesized arguments OR single-factor argument (e.g. sqrt9, sin30)
            val singleArgFunctions = setOf(
                "sin", "cos", "tan", "cot", "asin", "acos", "atan", "acot",
                "sinh", "cosh", "tanh", "asinh", "acosh", "atanh",
                "sqrt", "cbrt", "log", "ln", "abs", "ceil", "floor", "exp"
            )
            val multiArgFunctions = setOf(
                "logb", "nthroot", "npr", "ncr", "gcd", "lcm", "mod",
                "randint", "pol", "rec", "min", "max"
            )

            if (lower == "rand" || lower == "ran") {
                if (peek() == '(') extractParenthesizedRaw()
                return Random.nextDouble()
            }

            if (lower in multiArgFunctions) {
                val args = parseArgList()
                return when (lower) {
                    "logb" -> {
                        requireArgs(args, 2)
                        ln(args[1]) / ln(args[0])
                    }
                    "nthroot" -> {
                        requireArgs(args, 2)
                        val n = args[0]
                        val x = args[1]
                        if (x < 0 && n % 2.0 == 1.0) -abs(x).pow(1.0 / n) else x.pow(1.0 / n)
                    }
                    "npr" -> { requireArgs(args, 2); nPr(args[0], args[1]) }
                    "ncr" -> { requireArgs(args, 2); nCr(args[0], args[1]) }
                    "gcd" -> { requireArgs(args, 2); gcd(args[0].toLong(), args[1].toLong()).toDouble() }
                    "lcm" -> { requireArgs(args, 2); lcm(args[0].toLong(), args[1].toLong()).toDouble() }
                    "mod" -> {
                        requireArgs(args, 2)
                        if (args[1] == 0.0) throw IllegalArgumentException("Division by Zero")
                        args[0] % args[1]
                    }
                    "randint" -> {
                        requireArgs(args, 2)
                        val lo = min(args[0].toInt(), args[1].toInt())
                        val hi = max(args[0].toInt(), args[1].toInt())
                        Random.nextInt(lo, hi + 1).toDouble()
                    }
                    "pol" -> { requireArgs(args, 2); hypot(args[0], args[1]) }
                    "rec" -> { requireArgs(args, 2); args[0] * cos(toRadians(args[1], angleUnit)) }
                    "min" -> args.minOrNull() ?: throw IllegalArgumentException("Missing Args")
                    "max" -> args.maxOrNull() ?: throw IllegalArgumentException("Missing Args")
                    else -> throw IllegalArgumentException("Unknown Function")
                }
            }

            if (lower in singleArgFunctions) {
                val x = if (peek() == '(') {
                    val args = parseArgList()
                    requireArgs(args, 1)
                    args[0]
                } else {
                    parseUnary()
                }
                return when (lower) {
                    "sin" -> sin(toRadians(x, angleUnit))
                    "cos" -> cos(toRadians(x, angleUnit))
                    "tan" -> {
                        val rad = toRadians(x, angleUnit)
                        if (abs(cos(rad)) < 1e-15) throw IllegalArgumentException("Math Error")
                        tan(rad)
                    }
                    "cot" -> {
                        val rad = toRadians(x, angleUnit)
                        val t = tan(rad)
                        if (abs(t) < 1e-15) throw IllegalArgumentException("Math Error")
                        1.0 / t
                    }
                    "asin" -> {
                        if (x < -1.0 || x > 1.0) throw IllegalArgumentException("Domain Error")
                        fromRadians(asin(x), angleUnit)
                    }
                    "acos" -> {
                        if (x < -1.0 || x > 1.0) throw IllegalArgumentException("Domain Error")
                        fromRadians(acos(x), angleUnit)
                    }
                    "atan" -> fromRadians(atan(x), angleUnit)
                    "acot" -> fromRadians(PI / 2.0 - atan(x), angleUnit)
                    "sinh" -> sinh(x)
                    "cosh" -> cosh(x)
                    "tanh" -> tanh(x)
                    "asinh" -> asinh(x)
                    "acosh" -> {
                        if (x < 1.0) throw IllegalArgumentException("Domain Error")
                        acosh(x)
                    }
                    "atanh" -> {
                        if (x <= -1.0 || x >= 1.0) throw IllegalArgumentException("Domain Error")
                        atanh(x)
                    }
                    "sqrt" -> {
                        if (x < 0.0) throw IllegalArgumentException("Domain Error")
                        sqrt(x)
                    }
                    "cbrt" -> cbrt(x)
                    "log" -> {
                        if (x <= 0.0) throw IllegalArgumentException("Domain Error")
                        log10(x)
                    }
                    "ln" -> {
                        if (x <= 0.0) throw IllegalArgumentException("Domain Error")
                        ln(x)
                    }
                    "abs" -> abs(x)
                    "ceil" -> ceil(x)
                    "floor" -> floor(x)
                    "exp" -> exp(x)
                    else -> throw IllegalArgumentException("Unknown Function")
                }
            }

            // Built-in constants & memory variables
            return when (lower) {
                "pi" -> PI
                "e" -> E
                "ans" -> variables["Ans"] ?: 0.0
                "preans" -> variables["PreAns"] ?: 0.0
                else -> variables[name]
                    ?: variables[name.uppercase()]
                    ?: variables[lower]
                    ?: throw IllegalArgumentException("Unknown: $name")
            }
        }

        private fun evalArg(arg: String): Double {
            return when (val r = evaluate(arg, angleUnit, variables)) {
                is EvalResult.Success -> r.value
                is EvalResult.Error -> throw IllegalArgumentException(r.message)
            }
        }

        private fun requireArgs(args: List<Double>, count: Int) {
            if (args.size < count) throw IllegalArgumentException("Missing Arguments")
        }
    }
}
