package com.almaz.calc.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

enum class CalculatorSkinId {
    AMOLED_PRO,
    PURE_AMOLED,
    SLATE_CLASSIC,
    MODERN_LIGHT,
    MATERIAL_YOU
}

data class CalculatorSkinPalette(
    val id: CalculatorSkinId,
    val isDarkBody: Boolean,
    val bodyBg: Color,
    val displayBg: Color,
    val displayBorder: Color,
    val displayPrimaryText: Color,
    val displaySecondaryText: Color,
    val displayStatusText: Color,
    val cursorColor: Color,
    val toolbarIconBg: Color,
    val toolbarIconTint: Color,
    val shiftKeyBg: Color,
    val shiftKeyText: Color,
    val alphaKeyBg: Color,
    val alphaKeyText: Color,
    val shiftHintColor: Color,
    val alphaHintColor: Color,
    val sciKeyBg: Color,
    val sciKeyText: Color,
    val numKeyBg: Color,
    val numKeyText: Color,
    val opKeyBg: Color,
    val opKeyText: Color,
    val delAcKeyBg: Color,
    val delAcKeyText: Color,
    val equalsKeyBg: Color,
    val equalsKeyText: Color,
    val dpadOuterBg: Color,
    val dpadInnerBg: Color,
    val dpadIconTint: Color,
    val accentColor: Color
)

@Composable
fun resolveSkinPalette(skinId: CalculatorSkinId): CalculatorSkinPalette {
    val context = LocalContext.current
    val systemDark = isSystemInDarkTheme()

    return when (skinId) {
        // Inspired by Screenshot 3: Black AMOLED body, pale mint LCD, amber SHIFT, lavender ALPHA, orange DEL/AC
        CalculatorSkinId.AMOLED_PRO -> CalculatorSkinPalette(
            id = CalculatorSkinId.AMOLED_PRO,
            isDarkBody = true,
            bodyBg = Color(0xFF000000),
            displayBg = Color(0xFFD6E6E2),
            displayBorder = Color(0xFF1F2625),
            displayPrimaryText = Color(0xFF121A18),
            displaySecondaryText = Color(0xFF3A4A46),
            displayStatusText = Color(0xFF283532),
            cursorColor = Color(0xFF6A48D7),
            toolbarIconBg = Color(0xFF222328),
            toolbarIconTint = Color(0xFFE6E8EC),
            shiftKeyBg = Color(0xFFFFCA28),
            shiftKeyText = Color(0xFF1A1400),
            alphaKeyBg = Color(0xFF8E7CC3),
            alphaKeyText = Color(0xFFFFFFFF),
            shiftHintColor = Color(0xFFFFD54F),
            alphaHintColor = Color(0xFFB39DDB),
            sciKeyBg = Color(0xFF3E3F44),
            sciKeyText = Color(0xFFF3F4F6),
            numKeyBg = Color(0xFF232428),
            numKeyText = Color(0xFFFFFFFF),
            opKeyBg = Color(0xFF2E3036),
            opKeyText = Color(0xFFFFFFFF),
            delAcKeyBg = Color(0xFFF39C53),
            delAcKeyText = Color(0xFF1C1005),
            equalsKeyBg = Color(0xFF3A3D46),
            equalsKeyText = Color(0xFFFFFFFF),
            dpadOuterBg = Color(0xFF47484E),
            dpadInnerBg = Color(0xFF121316),
            dpadIconTint = Color(0xFFDDE0E6),
            accentColor = Color(0xFF9D8BF0)
        )

        // Pure 100% AMOLED Dark Mode (Pure black screen & body for OLED savings)
        CalculatorSkinId.PURE_AMOLED -> CalculatorSkinPalette(
            id = CalculatorSkinId.PURE_AMOLED,
            isDarkBody = true,
            bodyBg = Color(0xFF000000),
            displayBg = Color(0xFF07090C),
            displayBorder = Color(0xFF1E222A),
            displayPrimaryText = Color(0xFFF5F8FA),
            displaySecondaryText = Color(0xFF64DFDF),
            displayStatusText = Color(0xFF8E99A8),
            cursorColor = Color(0xFF64DFDF),
            toolbarIconBg = Color(0xFF13161B),
            toolbarIconTint = Color(0xFFD8E1EA),
            shiftKeyBg = Color(0xFFFFB300),
            shiftKeyText = Color(0xFF120D00),
            alphaKeyBg = Color(0xFF9C6ADE),
            alphaKeyText = Color(0xFFFFFFFF),
            shiftHintColor = Color(0xFFFFCA28),
            alphaHintColor = Color(0xFFC4A1FF),
            sciKeyBg = Color(0xFF16181D),
            sciKeyText = Color(0xFFE6ECF2),
            numKeyBg = Color(0xFF0E1014),
            numKeyText = Color(0xFFFFFFFF),
            opKeyBg = Color(0xFF191D24),
            opKeyText = Color(0xFF80DEEA),
            delAcKeyBg = Color(0xFFE65100),
            delAcKeyText = Color(0xFFFFFFFF),
            equalsKeyBg = Color(0xFF00897B),
            equalsKeyText = Color(0xFFFFFFFF),
            dpadOuterBg = Color(0xFF1B1E24),
            dpadInnerBg = Color(0xFF050608),
            dpadIconTint = Color(0xFFCFD8DC),
            accentColor = Color(0xFF64DFDF)
        )

        // Inspired by Screenshot 1: "Slate" classic Casio body, olive LCD screen, yellow SHIFT, crimson ALPHA
        CalculatorSkinId.SLATE_CLASSIC -> CalculatorSkinPalette(
            id = CalculatorSkinId.SLATE_CLASSIC,
            isDarkBody = true,
            bodyBg = Color(0xFF56595E),
            displayBg = Color(0xFFC2CBB6),
            displayBorder = Color(0xFF3E4145),
            displayPrimaryText = Color(0xFF1B1F19),
            displaySecondaryText = Color(0xFF373E34),
            displayStatusText = Color(0xFF2E342C),
            cursorColor = Color(0xFF1B1F19),
            toolbarIconBg = Color(0xFF6E7278),
            toolbarIconTint = Color(0xFFF5F6F8),
            shiftKeyBg = Color(0xFFD6B23A),
            shiftKeyText = Color(0xFF1E1A08),
            alphaKeyBg = Color(0xFFB7453F),
            alphaKeyText = Color(0xFFFFFFFF),
            shiftHintColor = Color(0xFFF0D578),
            alphaHintColor = Color(0xFFF29B96),
            sciKeyBg = Color(0xFFB9BCC1),
            sciKeyText = Color(0xFF1E2024),
            numKeyBg = Color(0xFF34373D),
            numKeyText = Color(0xFFFFFFFF),
            opKeyBg = Color(0xFF81858B),
            opKeyText = Color(0xFFFFFFFF),
            delAcKeyBg = Color(0xFF81858B),
            delAcKeyText = Color(0xFFFFFFFF),
            equalsKeyBg = Color(0xFF81858B),
            equalsKeyText = Color(0xFFFFFFFF),
            dpadOuterBg = Color(0xFFB9BCC1),
            dpadInnerBg = Color(0xFF56595E),
            dpadIconTint = Color(0xFF282B30),
            accentColor = Color(0xFFD6B23A)
        )

        // Inspired by Screenshot 2: "Modern" light casing, deep slate screen, blue SHIFT, pink ALPHA, blue DEL/AC
        CalculatorSkinId.MODERN_LIGHT -> CalculatorSkinPalette(
            id = CalculatorSkinId.MODERN_LIGHT,
            isDarkBody = false,
            bodyBg = Color(0xFFE8EBEE),
            displayBg = Color(0xFF2D3940),
            displayBorder = Color(0xFF202A30),
            displayPrimaryText = Color(0xFFF4F8FA),
            displaySecondaryText = Color(0xFF90CAF9),
            displayStatusText = Color(0xFFB0BEC5),
            cursorColor = Color(0xFF42A5F5),
            toolbarIconBg = Color(0xFFD3D8DE),
            toolbarIconTint = Color(0xFF263238),
            shiftKeyBg = Color(0xFF1E78E8),
            shiftKeyText = Color(0xFFFFFFFF),
            alphaKeyBg = Color(0xFFD81B60),
            alphaKeyText = Color(0xFFFFFFFF),
            shiftHintColor = Color(0xFF1565C0),
            alphaHintColor = Color(0xFFC2185B),
            sciKeyBg = Color(0xFF4F606B),
            sciKeyText = Color(0xFFFFFFFF),
            numKeyBg = Color(0xFF4F606B),
            numKeyText = Color(0xFFFFFFFF),
            opKeyBg = Color(0xFF5D707D),
            opKeyText = Color(0xFFFFFFFF),
            delAcKeyBg = Color(0xFF1E78E8),
            delAcKeyText = Color(0xFFFFFFFF),
            equalsKeyBg = Color(0xFF4F606B),
            equalsKeyText = Color(0xFFFFFFFF),
            dpadOuterBg = Color(0xFF45545E),
            dpadInnerBg = Color(0xFF566875),
            dpadIconTint = Color(0xFFECEFF1),
            accentColor = Color(0xFF1E78E8)
        )

        // Material You Dynamic Palette (Android 12+ dynamic wallpaper colors, M3 fallback below API 31)
        CalculatorSkinId.MATERIAL_YOU -> {
            val scheme: ColorScheme = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (systemDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
            } else {
                if (systemDark) {
                    darkColorScheme(
                        primary = Color(0xFFB6C4FF),
                        onPrimary = Color(0xFF1A2A66),
                        secondary = Color(0xFFD0BCFF),
                        onSecondary = Color(0xFF381E72),
                        tertiary = Color(0xFFEFB8C8),
                        onTertiary = Color(0xFF492532),
                        background = Color(0xFF10131A),
                        surface = Color(0xFF1B1F2A),
                        surfaceVariant = Color(0xFF282D3B)
                    )
                } else {
                    lightColorScheme(
                        primary = Color(0xFF3F5AA9),
                        onPrimary = Color(0xFFFFFFFF),
                        secondary = Color(0xFF6750A4),
                        onSecondary = Color(0xFFFFFFFF),
                        tertiary = Color(0xFF7D5260),
                        onTertiary = Color(0xFFFFFFFF),
                        background = Color(0xFFF4F6FC),
                        surface = Color(0xFFE7ECF7),
                        surfaceVariant = Color(0xFFD9E1F2)
                    )
                }
            }

            CalculatorSkinPalette(
                id = CalculatorSkinId.MATERIAL_YOU,
                isDarkBody = systemDark,
                bodyBg = scheme.background,
                displayBg = scheme.surfaceVariant,
                displayBorder = scheme.outlineVariant,
                displayPrimaryText = scheme.onSurfaceVariant,
                displaySecondaryText = scheme.primary,
                displayStatusText = scheme.onSurfaceVariant.copy(alpha = 0.75f),
                cursorColor = scheme.primary,
                toolbarIconBg = scheme.surface,
                toolbarIconTint = scheme.onSurface,
                shiftKeyBg = scheme.primary,
                shiftKeyText = scheme.onPrimary,
                alphaKeyBg = scheme.tertiary,
                alphaKeyText = scheme.onTertiary,
                shiftHintColor = scheme.primary,
                alphaHintColor = scheme.tertiary,
                sciKeyBg = scheme.surfaceVariant,
                sciKeyText = scheme.onSurfaceVariant,
                numKeyBg = scheme.surface,
                numKeyText = scheme.onSurface,
                opKeyBg = scheme.secondaryContainer,
                opKeyText = scheme.onSecondaryContainer,
                delAcKeyBg = scheme.errorContainer,
                delAcKeyText = scheme.onErrorContainer,
                equalsKeyBg = scheme.primaryContainer,
                equalsKeyText = scheme.onPrimaryContainer,
                dpadOuterBg = scheme.surfaceVariant,
                dpadInnerBg = scheme.primaryContainer,
                dpadIconTint = scheme.onSurfaceVariant,
                accentColor = scheme.primary
            )
        }
    }
}
