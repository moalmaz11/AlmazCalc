package com.almaz.calc.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.almaz.calc.data.AppLanguage
import com.almaz.calc.data.CalculatorStorage
import com.almaz.calc.data.HistoryItem
import com.almaz.calc.data.UserSettings
import com.almaz.calc.engine.AngleUnit
import com.almaz.calc.engine.EvalResult
import com.almaz.calc.engine.MathEngine
import com.almaz.calc.ui.theme.CalculatorSkinId
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlin.math.abs

enum class DisplayFormatMode {
    DECIMAL,
    FRACTION,
    ENGINEERING,
    DMS,
    PRIME_FACTOR
}

data class CalculatorUiState(
    val expression: String = "",
    val cursorIndex: Int = 0,
    val liveResult: String = "",
    val finalResult: String = "",
    val lastNumericValue: Double? = null,
    val isError: Boolean = false,
    val justEvaluated: Boolean = false,
    val isShift: Boolean = false,
    val isAlpha: Boolean = false,
    val isHyp: Boolean = false,
    val isSecond: Boolean = false,
    val isStoPending: Boolean = false,
    val isRclPending: Boolean = false,
    val formatMode: DisplayFormatMode = DisplayFormatMode.DECIMAL,
    val settings: UserSettings = UserSettings(),
    val history: List<HistoryItem> = emptyList(),
    val historyNavIndex: Int = -1,
    val variables: Map<String, Double> = emptyMap(),
    val statusToast: String? = null
)

class CalculatorViewModel(application: Application) : AndroidViewModel(application) {
    private val storage = CalculatorStorage(application.applicationContext)

    private val _uiState = MutableStateFlow(
        CalculatorUiState(
            settings = storage.loadSettings(),
            history = storage.loadHistory(),
            variables = storage.loadVariables()
        )
    )
    val uiState: StateFlow<CalculatorUiState> = _uiState.asStateFlow()

    fun clearToast() {
        _uiState.update { it.copy(statusToast = null) }
    }

    fun showToast(msg: String) {
        _uiState.update { it.copy(statusToast = msg) }
    }

    // --- Modifier toggles ---
    fun toggleShift() {
        _uiState.update {
            it.copy(
                isShift = !it.isShift,
                isAlpha = false,
                isStoPending = false,
                isRclPending = false
            )
        }
    }

    fun toggleAlpha() {
        _uiState.update {
            it.copy(
                isAlpha = !it.isAlpha,
                isShift = false,
                isStoPending = false,
                isRclPending = false
            )
        }
    }

    fun toggleHyp() {
        _uiState.update { it.copy(isHyp = !it.isHyp, isShift = false, isAlpha = false) }
    }

    fun toggleSecond() {
        _uiState.update { it.copy(isSecond = !it.isSecond) }
    }

    fun startSto() {
        _uiState.update {
            it.copy(
                isStoPending = true,
                isRclPending = false,
                isShift = false,
                isAlpha = false,
                statusToast = "STO → Tap A, B, C, D, E, F, X, Y, or M"
            )
        }
    }

    fun startRcl() {
        _uiState.update {
            it.copy(
                isRclPending = true,
                isStoPending = false,
                isShift = false,
                isAlpha = false,
                statusToast = "RCL → Tap A, B, C, D, E, F, X, Y, or M"
            )
        }
    }

    fun handleVariableKey(varName: String) {
        val state = _uiState.value
        if (state.isStoPending) {
            val valueToStore = state.lastNumericValue ?: run {
                when (val r = MathEngine.evaluate(state.expression, state.settings.angleUnit, state.variables)) {
                    is EvalResult.Success -> r.value
                    is EvalResult.Error -> null
                }
            }
            if (valueToStore != null) {
                val updated = state.variables.toMutableMap()
                updated[varName] = valueToStore
                storage.saveVariables(updated)
                _uiState.update {
                    it.copy(
                        variables = updated,
                        isStoPending = false,
                        statusToast = "$varName = ${MathEngine.formatDecimal(valueToStore, it.settings.precision)}"
                    )
                }
            } else {
                _uiState.update { it.copy(isStoPending = false, statusToast = "Nothing to store") }
            }
            return
        }

        if (state.isRclPending) {
            val stored = state.variables[varName] ?: 0.0
            _uiState.update { it.copy(isRclPending = false) }
            insertToken(MathEngine.formatDecimal(stored, state.settings.precision))
            return
        }

        insertToken(varName)
    }

    fun memoryAdd(subtract: Boolean = false) {
        val state = _uiState.value
        val value = state.lastNumericValue ?: run {
            when (val r = MathEngine.evaluate(state.expression, state.settings.angleUnit, state.variables)) {
                is EvalResult.Success -> r.value
                is EvalResult.Error -> return
            }
        }
        val currentM = state.variables["M"] ?: 0.0
        val newM = if (subtract) currentM - value else currentM + value
        val updated = state.variables.toMutableMap()
        updated["M"] = newM
        storage.saveVariables(updated)
        _uiState.update {
            it.copy(
                variables = updated,
                isShift = false,
                isAlpha = false,
                statusToast = "M = ${MathEngine.formatDecimal(newM, it.settings.precision)}"
            )
        }
    }

    fun clearVariables() {
        storage.saveVariables(emptyMap())
        _uiState.update {
            it.copy(
                variables = emptyMap(),
                isShift = false,
                isAlpha = false,
                isStoPending = false,
                isRclPending = false,
                statusToast = "All variables cleared"
            )
        }
    }

    // --- Expression editing ---
    fun insertToken(token: String, cursorOffsetFromEnd: Int = 0) {
        _uiState.update { state ->
            val baseExpr: String
            val baseCursor: Int

            val isBinaryOp = token in setOf("+", "−", "×", "÷", "^", "²", "³", "⁻¹", "!", "%")
            if (state.justEvaluated && !state.isError) {
                if (isBinaryOp) {
                    baseExpr = "Ans"
                    baseCursor = baseExpr.length
                } else {
                    baseExpr = ""
                    baseCursor = 0
                }
            } else if (state.isError) {
                baseExpr = ""
                baseCursor = 0
            } else {
                baseExpr = state.expression
                baseCursor = state.cursorIndex.coerceIn(0, baseExpr.length)
            }

            val newExpr = baseExpr.substring(0, baseCursor) + token + baseExpr.substring(baseCursor)
            val newCursor = (baseCursor + token.length - cursorOffsetFromEnd).coerceIn(0, newExpr.length)

            val updated = state.copy(
                expression = newExpr,
                cursorIndex = newCursor,
                justEvaluated = false,
                isError = false,
                isShift = false,
                isAlpha = false,
                isHyp = false,
                isStoPending = false,
                isRclPending = false,
                formatMode = DisplayFormatMode.DECIMAL,
                historyNavIndex = -1
            )
            recomputeLive(updated)
        }
    }

    fun backspace() {
        _uiState.update { state ->
            if (state.expression.isEmpty()) return@update state.copy(isShift = false, isAlpha = false)
            val cursor = state.cursorIndex.coerceIn(0, state.expression.length)
            if (cursor == 0) return@update state
            val newExpr = state.expression.removeRange(cursor - 1, cursor)
            val updated = state.copy(
                expression = newExpr,
                cursorIndex = cursor - 1,
                justEvaluated = false,
                isError = false,
                isShift = false,
                isAlpha = false,
                formatMode = DisplayFormatMode.DECIMAL
            )
            recomputeLive(updated)
        }
    }

    fun clearExpression() {
        _uiState.update {
            it.copy(
                expression = "",
                cursorIndex = 0,
                liveResult = "",
                finalResult = "",
                isError = false,
                justEvaluated = false,
                isShift = false,
                isAlpha = false,
                isHyp = false,
                isStoPending = false,
                isRclPending = false,
                formatMode = DisplayFormatMode.DECIMAL,
                historyNavIndex = -1
            )
        }
    }

    fun clearAll() {
        clearExpression()
        clearVariables()
    }

    // --- D-Pad Navigation ---
    fun moveCursorLeft() {
        _uiState.update { state ->
            val next = (state.cursorIndex - 1).coerceAtLeast(0)
            state.copy(cursorIndex = next, justEvaluated = false)
        }
    }

    fun moveCursorRight() {
        _uiState.update { state ->
            val next = (state.cursorIndex + 1).coerceAtMost(state.expression.length)
            state.copy(cursorIndex = next, justEvaluated = false)
        }
    }

    fun navigateHistoryUp() {
        _uiState.update { state ->
            if (state.history.isEmpty()) return@update state
            val nextIdx = (state.historyNavIndex + 1).coerceAtMost(state.history.lastIndex)
            val item = state.history[nextIdx]
            val updated = state.copy(
                expression = item.expression,
                cursorIndex = item.expression.length,
                historyNavIndex = nextIdx,
                justEvaluated = false,
                isError = false
            )
            recomputeLive(updated)
        }
    }

    fun navigateHistoryDown() {
        _uiState.update { state ->
            if (state.history.isEmpty() || state.historyNavIndex <= 0) {
                return@update state.copy(historyNavIndex = -1)
            }
            val nextIdx = state.historyNavIndex - 1
            val item = state.history[nextIdx]
            val updated = state.copy(
                expression = item.expression,
                cursorIndex = item.expression.length,
                historyNavIndex = nextIdx,
                justEvaluated = false,
                isError = false
            )
            recomputeLive(updated)
        }
    }

    // --- Evaluation & Formatting ---
    fun evaluateExpression() {
        val state = _uiState.value
        val expr = state.expression.trim()
        if (expr.isEmpty()) return

        val evalResult = if (expr.contains("=") && !expr.startsWith("solve(")) {
            MathEngine.solveEquation(expr, 1.0, state.settings.angleUnit, state.variables)
        } else {
            MathEngine.evaluate(expr, state.settings.angleUnit, state.variables)
        }

        when (evalResult) {
            is EvalResult.Success -> {
                val formatted = MathEngine.formatDecimal(evalResult.value, state.settings.precision)
                val updatedVars = state.variables.toMutableMap()
                updatedVars["Ans"]?.let { prev -> updatedVars["PreAns"] = prev }
                updatedVars["Ans"] = evalResult.value
                storage.saveVariables(updatedVars)

                val newHistoryItem = HistoryItem(
                    id = System.currentTimeMillis(),
                    expression = expr,
                    result = formatted,
                    timestamp = System.currentTimeMillis()
                )
                val newHistory = (listOf(newHistoryItem) + state.history).take(100)
                storage.saveHistory(newHistory)

                _uiState.update {
                    it.copy(
                        finalResult = formatted,
                        liveResult = formatted,
                        lastNumericValue = evalResult.value,
                        isError = false,
                        justEvaluated = true,
                        isShift = false,
                        isAlpha = false,
                        isHyp = false,
                        formatMode = DisplayFormatMode.DECIMAL,
                        variables = updatedVars,
                        history = newHistory,
                        historyNavIndex = -1
                    )
                }
            }
            is EvalResult.Error -> {
                _uiState.update {
                    it.copy(
                        finalResult = evalResult.message,
                        isError = true,
                        justEvaluated = true,
                        isShift = false,
                        isAlpha = false
                    )
                }
            }
        }
    }

    fun solveCurrentExpression() {
        val state = _uiState.value
        val expr = state.expression.trim()
        if (expr.isEmpty()) {
            insertToken("solve(,1)", cursorOffsetFromEnd = 3)
            return
        }
        when (val res = MathEngine.solveEquation(expr, 1.0, state.settings.angleUnit, state.variables)) {
            is EvalResult.Success -> {
                val formatted = "x = ${MathEngine.formatDecimal(res.value, state.settings.precision)}"
                val updatedVars = state.variables.toMutableMap()
                updatedVars["X"] = res.value
                updatedVars["Ans"] = res.value
                storage.saveVariables(updatedVars)
                _uiState.update {
                    it.copy(
                        finalResult = formatted,
                        liveResult = formatted,
                        lastNumericValue = res.value,
                        isError = false,
                        justEvaluated = true,
                        isShift = false,
                        isAlpha = false,
                        variables = updatedVars
                    )
                }
            }
            is EvalResult.Error -> {
                _uiState.update {
                    it.copy(
                        finalResult = res.message,
                        isError = true,
                        isShift = false,
                        isAlpha = false
                    )
                }
            }
        }
    }

    fun toggleFractionFormat() {
        _uiState.update { state ->
            val value = state.lastNumericValue ?: return@update state
            if (state.formatMode == DisplayFormatMode.FRACTION) {
                val dec = MathEngine.formatDecimal(value, state.settings.precision)
                state.copy(formatMode = DisplayFormatMode.DECIMAL, finalResult = dec, liveResult = dec)
            } else {
                val frac = MathEngine.toExactFraction(value)
                if (frac != null) {
                    state.copy(formatMode = DisplayFormatMode.FRACTION, finalResult = frac, liveResult = frac)
                } else {
                    state.copy(statusToast = "Exact fraction not available")
                }
            }
        }
    }

    fun toggleEngineeringFormat() {
        _uiState.update { state ->
            val value = state.lastNumericValue ?: return@update state
            if (state.formatMode == DisplayFormatMode.ENGINEERING) {
                val dec = MathEngine.formatDecimal(value, state.settings.precision)
                state.copy(formatMode = DisplayFormatMode.DECIMAL, finalResult = dec, liveResult = dec)
            } else {
                val eng = MathEngine.toEngineering(value, state.settings.precision)
                state.copy(formatMode = DisplayFormatMode.ENGINEERING, finalResult = eng, liveResult = eng)
            }
        }
    }

    fun toggleDmsFormat() {
        _uiState.update { state ->
            val value = state.lastNumericValue ?: return@update state
            if (state.formatMode == DisplayFormatMode.DMS) {
                val dec = MathEngine.formatDecimal(value, state.settings.precision)
                state.copy(formatMode = DisplayFormatMode.DECIMAL, finalResult = dec, liveResult = dec)
            } else {
                val dms = MathEngine.toDms(value)
                state.copy(formatMode = DisplayFormatMode.DMS, finalResult = dms, liveResult = dms)
            }
        }
    }

    fun applyPrimeFactorization() {
        _uiState.update { state ->
            val value = state.lastNumericValue ?: return@update state.copy(isShift = false)
            if (abs(value - kotlin.math.floor(value)) < 1e-9 && value >= 2.0) {
                val factored = MathEngine.primeFactorize(value)
                state.copy(
                    formatMode = DisplayFormatMode.PRIME_FACTOR,
                    finalResult = factored,
                    liveResult = factored,
                    isShift = false
                )
            } else {
                state.copy(isShift = false, statusToast = "FACT requires integer ≥ 2")
            }
        }
    }

    private fun recomputeLive(state: CalculatorUiState): CalculatorUiState {
        if (state.expression.isBlank()) {
            return state.copy(liveResult = "", finalResult = "")
        }
        return when (val r = MathEngine.evaluate(state.expression, state.settings.angleUnit, state.variables)) {
            is EvalResult.Success -> {
                val formatted = MathEngine.formatDecimal(r.value, state.settings.precision)
                state.copy(liveResult = formatted, lastNumericValue = r.value)
            }
            is EvalResult.Error -> state.copy(liveResult = "")
        }
    }

    // --- History actions ---
    fun useHistoryExpression(item: HistoryItem) {
        _uiState.update { state ->
            val updated = state.copy(
                expression = item.expression,
                cursorIndex = item.expression.length,
                justEvaluated = false,
                isError = false
            )
            recomputeLive(updated)
        }
    }

    fun clearHistory() {
        storage.saveHistory(emptyList())
        _uiState.update { it.copy(history = emptyList(), historyNavIndex = -1) }
    }

    // --- Settings updates ---
    fun cycleAngleUnit() {
        updateSettings { it.copy(angleUnit = it.angleUnit.next()) }
    }

    fun setAngleUnit(unit: AngleUnit) {
        updateSettings { it.copy(angleUnit = unit) }
    }

    fun setSkin(skin: CalculatorSkinId) {
        updateSettings { it.copy(skin = skin) }
    }

    fun setLanguage(lang: AppLanguage) {
        updateSettings { it.copy(language = lang) }
    }

    fun setPrecision(precision: Int) {
        updateSettings { it.copy(precision = precision.coerceIn(2, 12)) }
    }

    fun setHapticEnabled(enabled: Boolean) {
        updateSettings { it.copy(hapticEnabled = enabled) }
    }

    fun setKeepScreenOn(enabled: Boolean) {
        updateSettings { it.copy(keepScreenOn = enabled) }
    }

    private fun updateSettings(transform: (UserSettings) -> UserSettings) {
        _uiState.update { state ->
            val nextSettings = transform(state.settings)
            storage.saveSettings(nextSettings)
            recomputeLive(state.copy(settings = nextSettings))
        }
    }
}
