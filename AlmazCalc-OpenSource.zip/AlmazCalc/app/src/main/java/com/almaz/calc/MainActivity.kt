@file:OptIn(ExperimentalMaterial3Api::class)

package com.almaz.calc

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.Functions
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.almaz.calc.data.AppLanguage
import com.almaz.calc.data.stringsFor
import com.almaz.calc.ui.components.CalculatorDisplay
import com.almaz.calc.ui.components.QuickToolbar
import com.almaz.calc.ui.components.ScientificKeypad
import com.almaz.calc.ui.screens.ConstantsBottomSheet
import com.almaz.calc.ui.screens.HistoryBottomSheet
import com.almaz.calc.ui.screens.SettingsBottomSheet
import com.almaz.calc.ui.screens.SkinsBottomSheet
import com.almaz.calc.ui.screens.UnitConverterBottomSheet
import com.almaz.calc.ui.screens.VariablesBottomSheet
import com.almaz.calc.ui.theme.CalculatorSkinId
import com.almaz.calc.ui.theme.resolveSkinPalette
import com.almaz.calc.viewmodel.CalculatorViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AlmazCalcRoot()
        }
    }
}

private enum class ActiveSheet {
    NONE, SKINS, CONVERTER, CONSTANTS, HISTORY, VARIABLES, SETTINGS
}

@Composable
fun AlmazCalcRoot(vm: CalculatorViewModel = viewModel()) {
    val state by vm.uiState.collectAsState()
    val palette = resolveSkinPalette(state.settings.skin)
    val strings = stringsFor(state.settings.language)
    val context = LocalContext.current
    val view = LocalView.current
    val systemDark = isSystemInDarkTheme()

    // Apply Material 3 scheme for sheets, drawers & dialogs
    val m3ColorScheme = when {
        state.settings.skin == CalculatorSkinId.MATERIAL_YOU && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (systemDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        palette.isDarkBody -> darkColorScheme(primary = palette.accentColor)
        else -> lightColorScheme(primary = palette.accentColor)
    }

    // Update status bar & navigation bar colors to seamlessly match calculator body
    DisposableEffect(palette.bodyBg, palette.isDarkBody, state.settings.keepScreenOn) {
        val window = (view.context as? Activity)?.window
        if (window != null) {
            window.statusBarColor = palette.bodyBg.toArgb()
            window.navigationBarColor = palette.bodyBg.toArgb()
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !palette.isDarkBody
            controller.isAppearanceLightNavigationBars = !palette.isDarkBody

            if (state.settings.keepScreenOn) {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
        onDispose { }
    }

    val layoutDir = if (state.settings.language == AppLanguage.ARABIC) {
        LayoutDirection.Rtl
    } else {
        LayoutDirection.Ltr
    }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(state.statusToast) {
        val msg = state.statusToast
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            vm.clearToast()
        }
    }

    var activeSheet by remember { mutableStateOf(ActiveSheet.NONE) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = m3ColorScheme) {
        CompositionLocalProvider(LocalLayoutDirection provides layoutDir) {
            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    ModalDrawerSheet {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Text(
                                text = strings.appTitle,
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = strings.offlineBadge,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(8.dp))

                        NavigationDrawerItem(
                            icon = { Icon(Icons.Rounded.Calculate, contentDescription = null) },
                            label = { Text(strings.calculator) },
                            selected = activeSheet == ActiveSheet.NONE,
                            onClick = { scope.launch { drawerState.close() } },
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                        NavigationDrawerItem(
                            icon = { Icon(Icons.Rounded.SwapHoriz, contentDescription = null) },
                            label = { Text(strings.unitConverter) },
                            selected = activeSheet == ActiveSheet.CONVERTER,
                            onClick = {
                                scope.launch { drawerState.close() }
                                activeSheet = ActiveSheet.CONVERTER
                            },
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                        NavigationDrawerItem(
                            icon = { Icon(Icons.Rounded.Science, contentDescription = null) },
                            label = { Text(strings.constants) },
                            selected = activeSheet == ActiveSheet.CONSTANTS,
                            onClick = {
                                scope.launch { drawerState.close() }
                                activeSheet = ActiveSheet.CONSTANTS
                            },
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                        NavigationDrawerItem(
                            icon = { Icon(Icons.Rounded.History, contentDescription = null) },
                            label = { Text(strings.history) },
                            selected = activeSheet == ActiveSheet.HISTORY,
                            onClick = {
                                scope.launch { drawerState.close() }
                                activeSheet = ActiveSheet.HISTORY
                            },
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                        NavigationDrawerItem(
                            icon = { Icon(Icons.Rounded.Functions, contentDescription = null) },
                            label = { Text(strings.variables) },
                            selected = activeSheet == ActiveSheet.VARIABLES,
                            onClick = {
                                scope.launch { drawerState.close() }
                                activeSheet = ActiveSheet.VARIABLES
                            },
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                        NavigationDrawerItem(
                            icon = { Icon(Icons.Rounded.Palette, contentDescription = null) },
                            label = { Text(strings.skins) },
                            selected = activeSheet == ActiveSheet.SKINS,
                            onClick = {
                                scope.launch { drawerState.close() }
                                activeSheet = ActiveSheet.SKINS
                            },
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                        NavigationDrawerItem(
                            icon = { Icon(Icons.Rounded.Settings, contentDescription = null) },
                            label = { Text(strings.settings) },
                            selected = activeSheet == ActiveSheet.SETTINGS,
                            onClick = {
                                scope.launch { drawerState.close() }
                                activeSheet = ActiveSheet.SETTINGS
                            },
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )

                        Spacer(modifier = Modifier.weight(1f))
                        HorizontalDivider()
                        Text(
                            text = "Made with love by Mostafa Almaz 🤍",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(20.dp)
                        )
                    }
                }
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = palette.bodyBg
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(palette.bodyBg)
                            .statusBarsPadding()
                            .navigationBarsPadding()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            // Top Scientific LCD Screen (approx 24% height)
                            CalculatorDisplay(
                                state = state,
                                palette = palette,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(0.24f)
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            // Icon Toolbar Strip (Menu, Skins, Constants, Settings, Converter, History, DEG)
                            QuickToolbar(
                                state = state,
                                palette = palette,
                                onOpenMenu = { scope.launch { drawerState.open() } },
                                onOpenSkins = { activeSheet = ActiveSheet.SKINS },
                                onOpenConstants = { activeSheet = ActiveSheet.CONSTANTS },
                                onOpenSettings = { activeSheet = ActiveSheet.SETTINGS },
                                onOpenConverter = { activeSheet = ActiveSheet.CONVERTER },
                                onOpenHistory = { activeSheet = ActiveSheet.HISTORY },
                                onCycleAngle = { vm.cycleAngleUnit() }
                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            // Full Casio 991-Inspired Scientific + Numeric Keypad (approx 72% height)
                            ScientificKeypad(
                                state = state,
                                palette = palette,
                                viewModel = vm,
                                onOpenConverter = { activeSheet = ActiveSheet.CONVERTER },
                                onOpenConstants = { activeSheet = ActiveSheet.CONSTANTS },
                                onOpenHistory = { activeSheet = ActiveSheet.HISTORY },
                                onOpenVariables = { activeSheet = ActiveSheet.VARIABLES },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(0.76f)
                            )
                        }

                        SnackbarHost(
                            hostState = snackbarHostState,
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 12.dp, start = 16.dp, end = 16.dp)
                        )
                    }
                }
            }

            // Bottom Sheets
            when (activeSheet) {
                ActiveSheet.SKINS -> SkinsBottomSheet(
                    currentSkin = state.settings.skin,
                    strings = strings,
                    onSelectSkin = { vm.setSkin(it) },
                    onDismiss = { activeSheet = ActiveSheet.NONE }
                )

                ActiveSheet.CONVERTER -> UnitConverterBottomSheet(
                    language = state.settings.language,
                    strings = strings,
                    precision = state.settings.precision,
                    onInsertResult = { vm.insertToken(it) },
                    onDismiss = { activeSheet = ActiveSheet.NONE }
                )

                ActiveSheet.CONSTANTS -> ConstantsBottomSheet(
                    language = state.settings.language,
                    strings = strings,
                    onInsertConstant = { value ->
                        vm.insertToken(value.toString())
                    },
                    onDismiss = { activeSheet = ActiveSheet.NONE }
                )

                ActiveSheet.HISTORY -> HistoryBottomSheet(
                    history = state.history,
                    strings = strings,
                    onSelectItem = { vm.useHistoryExpression(it) },
                    onClearHistory = { vm.clearHistory() },
                    onCopied = { vm.showToast("${strings.copied}: $it") },
                    onDismiss = { activeSheet = ActiveSheet.NONE }
                )

                ActiveSheet.VARIABLES -> VariablesBottomSheet(
                    variables = state.variables,
                    precision = state.settings.precision,
                    strings = strings,
                    onInsertVar = { vm.insertToken(it) },
                    onClearVariables = { vm.clearVariables() },
                    onDismiss = { activeSheet = ActiveSheet.NONE }
                )

                ActiveSheet.SETTINGS -> SettingsBottomSheet(
                    settings = state.settings,
                    strings = strings,
                    onLanguageChange = { vm.setLanguage(it) },
                    onAngleUnitChange = { vm.setAngleUnit(it) },
                    onPrecisionChange = { vm.setPrecision(it) },
                    onHapticChange = { vm.setHapticEnabled(it) },
                    onKeepScreenOnChange = { vm.setKeepScreenOn(it) },
                    onOpenSkins = { activeSheet = ActiveSheet.SKINS },
                    onDismiss = { activeSheet = ActiveSheet.NONE }
                )

                ActiveSheet.NONE -> Unit
            }
        }
    }
}
