package com.almaz.calc.data

data class UnitItem(
    val id: String,
    val nameEn: String,
    val nameAr: String,
    val symbol: String,
    val toBase: (Double) -> Double,
    val fromBase: (Double) -> Double
)

data class UnitCategory(
    val id: String,
    val nameEn: String,
    val nameAr: String,
    val units: List<UnitItem>
)

data class ScientificConstant(
    val symbol: String,
    val nameEn: String,
    val nameAr: String,
    val value: Double,
    val displayValue: String,
    val unit: String
)

private fun linearUnit(
    id: String,
    nameEn: String,
    nameAr: String,
    symbol: String,
    factorToBase: Double
) = UnitItem(
    id = id,
    nameEn = nameEn,
    nameAr = nameAr,
    symbol = symbol,
    toBase = { it * factorToBase },
    fromBase = { it / factorToBase }
)

object ConverterRepository {

    val categories: List<UnitCategory> = listOf(
        UnitCategory(
            id = "length",
            nameEn = "Length",
            nameAr = "الطول",
            units = listOf(
                linearUnit("m", "Meter", "متر", "m", 1.0),
                linearUnit("km", "Kilometer", "كيلومتر", "km", 1000.0),
                linearUnit("cm", "Centimeter", "سنتيمتر", "cm", 0.01),
                linearUnit("mm", "Millimeter", "ملليمتر", "mm", 0.001),
                linearUnit("um", "Micrometer", "ميكرومتر", "μm", 1e-6),
                linearUnit("nm", "Nanometer", "نانومتر", "nm", 1e-9),
                linearUnit("in", "Inch", "بوصة", "in", 0.0254),
                linearUnit("ft", "Foot", "قدم", "ft", 0.3048),
                linearUnit("yd", "Yard", "ياردة", "yd", 0.9144),
                linearUnit("mi", "Mile", "ميل", "mi", 1609.344),
                linearUnit("nmi", "Nautical Mile", "ميل بحري", "nmi", 1852.0)
            )
        ),
        UnitCategory(
            id = "mass",
            nameEn = "Mass",
            nameAr = "الكتلة",
            units = listOf(
                linearUnit("kg", "Kilogram", "كيلوجرام", "kg", 1.0),
                linearUnit("g", "Gram", "جرام", "g", 0.001),
                linearUnit("mg", "Milligram", "ملليجرام", "mg", 1e-6),
                linearUnit("t", "Metric Ton", "طن متري", "t", 1000.0),
                linearUnit("lb", "Pound", "رطل", "lb", 0.45359237),
                linearUnit("oz", "Ounce", "أوقية", "oz", 0.028349523125),
                linearUnit("u", "Atomic Mass Unit", "وحدة كتل ذرية", "u", 1.6605390666e-27)
            )
        ),
        UnitCategory(
            id = "temp",
            nameEn = "Temperature",
            nameAr = "الحرارة",
            units = listOf(
                UnitItem("c", "Celsius", "سيليزيوس", "°C", { it }, { it }),
                UnitItem("f", "Fahrenheit", "فهرنهايت", "°F", { (it - 32.0) * 5.0 / 9.0 }, { it * 9.0 / 5.0 + 32.0 }),
                UnitItem("k", "Kelvin", "كلفن", "K", { it - 273.15 }, { it + 273.15 })
            )
        ),
        UnitCategory(
            id = "area",
            nameEn = "Area",
            nameAr = "المساحة",
            units = listOf(
                linearUnit("m2", "Square Meter", "متر مربع", "m²", 1.0),
                linearUnit("km2", "Square Kilometer", "كيلومتر مربع", "km²", 1e6),
                linearUnit("cm2", "Square Centimeter", "سنتيمتر مربع", "cm²", 1e-4),
                linearUnit("ha", "Hectare", "هكتار", "ha", 1e4),
                linearUnit("feddan", "Feddan (Egypt)", "فدان مصري", "fed", 4200.833),
                linearUnit("acre", "Acre", "أكر", "ac", 4046.8564224),
                linearUnit("ft2", "Square Foot", "قدم مربع", "ft²", 0.09290304)
            )
        ),
        UnitCategory(
            id = "volume",
            nameEn = "Volume",
            nameAr = "الحجم",
            units = listOf(
                linearUnit("l", "Liter", "لتر", "L", 1.0),
                linearUnit("ml", "Milliliter", "ملليلتر", "mL", 0.001),
                linearUnit("m3", "Cubic Meter", "متر مكعب", "m³", 1000.0),
                linearUnit("cm3", "Cubic Centimeter", "سم مكعب", "cm³", 0.001),
                linearUnit("gal", "US Gallon", "جالون أمريكي", "gal", 3.785411784),
                linearUnit("floz", "Fluid Ounce", "أوقية سائلة", "fl oz", 0.0295735296)
            )
        ),
        UnitCategory(
            id = "time",
            nameEn = "Time",
            nameAr = "الزمن",
            units = listOf(
                linearUnit("s", "Second", "ثانية", "s", 1.0),
                linearUnit("ms", "Millisecond", "مللي ثانية", "ms", 0.001),
                linearUnit("us", "Microsecond", "ميكرو ثانية", "μs", 1e-6),
                linearUnit("min", "Minute", "دقيقة", "min", 60.0),
                linearUnit("hr", "Hour", "ساعة", "h", 3600.0),
                linearUnit("day", "Day", "يوم", "d", 86400.0),
                linearUnit("wk", "Week", "أسبوع", "wk", 604800.0),
                linearUnit("yr", "Year", "سنة", "yr", 31557600.0)
            )
        ),
        UnitCategory(
            id = "speed",
            nameEn = "Speed",
            nameAr = "السرعة",
            units = listOf(
                linearUnit("mps", "Meter/Second", "متر/ثانية", "m/s", 1.0),
                linearUnit("kmh", "Kilometer/Hour", "كم/ساعة", "km/h", 1.0 / 3.6),
                linearUnit("mph", "Mile/Hour", "ميل/ساعة", "mph", 0.44704),
                linearUnit("kt", "Knot", "عقدة", "kn", 1852.0 / 3600.0),
                linearUnit("c", "Speed of Light", "سرعة الضوء", "c", 299792458.0)
            )
        ),
        UnitCategory(
            id = "data",
            nameEn = "Data",
            nameAr = "البيانات",
            units = listOf(
                linearUnit("b", "Bit", "بت", "b", 0.125),
                linearUnit("B", "Byte", "بايت", "B", 1.0),
                linearUnit("KB", "Kilobyte (KiB)", "كيلوبايت", "KB", 1024.0),
                linearUnit("MB", "Megabyte (MiB)", "ميجابايت", "MB", 1048576.0),
                linearUnit("GB", "Gigabyte (GiB)", "جيجابايت", "GB", 1073741824.0),
                linearUnit("TB", "Terabyte (TiB)", "تيرابايت", "TB", 1099511627776.0)
            )
        ),
        UnitCategory(
            id = "energy",
            nameEn = "Energy",
            nameAr = "الطاقة",
            units = listOf(
                linearUnit("J", "Joule", "جول", "J", 1.0),
                linearUnit("kJ", "Kilojoule", "كيلوجول", "kJ", 1000.0),
                linearUnit("cal", "Calorie", "سعر حراري", "cal", 4.184),
                linearUnit("kcal", "Kilocalorie", "كيلو سعر", "kcal", 4184.0),
                linearUnit("Wh", "Watt-Hour", "واط-ساعة", "Wh", 3600.0),
                linearUnit("kWh", "Kilowatt-Hour", "كيلوواط-ساعة", "kWh", 3.6e6),
                linearUnit("eV", "Electronvolt", "إلكترون فولت", "eV", 1.602176634e-19)
            )
        ),
        UnitCategory(
            id = "pressure",
            nameEn = "Pressure",
            nameAr = "الضغط",
            units = listOf(
                linearUnit("Pa", "Pascal", "باسكال", "Pa", 1.0),
                linearUnit("kPa", "Kilopascal", "كيلوباسكال", "kPa", 1000.0),
                linearUnit("bar", "Bar", "بار", "bar", 1e5),
                linearUnit("atm", "Atmosphere", "ضغط جوي", "atm", 101325.0),
                linearUnit("mmHg", "mmHg (Torr)", "ملليمتر زئبق", "mmHg", 133.322368),
                linearUnit("psi", "PSI", "رطل/بوصة²", "psi", 6894.757293)
            )
        ),
        UnitCategory(
            id = "power",
            nameEn = "Power",
            nameAr = "القدرة",
            units = listOf(
                linearUnit("W", "Watt", "واط", "W", 1.0),
                linearUnit("kW", "Kilowatt", "كيلوواط", "kW", 1000.0),
                linearUnit("MW", "Megawatt", "ميجاواط", "MW", 1e6),
                linearUnit("hp", "Horsepower", "حصان ميكانيكي", "hp", 745.699872)
            )
        ),
        UnitCategory(
            id = "angle",
            nameEn = "Angle",
            nameAr = "الزاوية",
            units = listOf(
                linearUnit("deg", "Degree", "درجة", "°", 1.0),
                linearUnit("rad", "Radian", "راديان", "rad", 180.0 / kotlin.math.PI),
                linearUnit("grad", "Gradian", "جراديان", "grad", 0.9)
            )
        )
    )

    val scientificConstants: List<ScientificConstant> = listOf(
        ScientificConstant("c", "Speed of Light in Vacuum", "سرعة الضوء في الفراغ", 299792458.0, "2.99792458×10⁸", "m/s"),
        ScientificConstant("g", "Standard Gravity", "عجلة الجاذبية الأرضية", 9.80665, "9.80665", "m/s²"),
        ScientificConstant("G", "Gravitational Constant", "ثابت الجذب العام", 6.67430e-11, "6.67430×10⁻¹¹", "m³/(kg·s²)"),
        ScientificConstant("h", "Planck Constant", "ثابت بلانك", 6.62607015e-34, "6.62607015×10⁻³⁴", "J·s"),
        ScientificConstant("ħ", "Reduced Planck Constant", "ثابت بلانك المختزل", 1.054571817e-34, "1.0545718×10⁻³⁴", "J·s"),
        ScientificConstant("Nₐ", "Avogadro Constant", "عدد أفوجادرو", 6.02214076e23, "6.02214076×10²³", "mol⁻¹"),
        ScientificConstant("R", "Molar Gas Constant", "الثابت العام للغازات", 8.314462618, "8.3144626", "J/(mol·K)"),
        ScientificConstant("kB", "Boltzmann Constant", "ثابت بولتزمان", 1.380649e-23, "1.380649×10⁻²³", "J/K"),
        ScientificConstant("e", "Elementary Charge", "شحنة الإلكترون", 1.602176634e-19, "1.602176634×10⁻¹⁹", "C"),
        ScientificConstant("F", "Faraday Constant", "ثابت فاراداي", 96485.33212, "96485.332", "C/mol"),
        ScientificConstant("mₑ", "Electron Mass", "كتلة الإلكترون", 9.1093837015e-31, "9.1093837×10⁻³¹", "kg"),
        ScientificConstant("mₚ", "Proton Mass", "كتلة البروتون", 1.67262192369e-27, "1.6726219×10⁻²⁷", "kg"),
        ScientificConstant("mₙ", "Neutron Mass", "كتلة النيوترون", 1.67492749804e-27, "1.6749275×10⁻²⁷", "kg"),
        ScientificConstant("ε₀", "Vacuum Permittivity", "سماحية الفراغ الكهربية", 8.8541878128e-12, "8.8541878×10⁻¹²", "F/m"),
        ScientificConstant("μ₀", "Vacuum Permeability", "نفاذية الفراغ المغناطيسية", 1.25663706212e-6, "1.2566371×10⁻⁶", "N/A²"),
        ScientificConstant("kₑ", "Coulomb Constant", "ثابت كولوم", 8.9875517923e9, "8.9875518×10⁹", "N·m²/C²"),
        ScientificConstant("σ", "Stefan-Boltzmann Constant", "ثابت ستيفان-بولتزمان", 5.670374419e-8, "5.6703744×10⁻⁸", "W/(m²·K⁴)"),
        ScientificConstant("Vₘ", "Molar Volume (STP)", "الحجم المولي للغاز", 22.41396954, "22.41397", "L/mol"),
        ScientificConstant("R∞", "Rydberg Constant", "ثابت ريدبرج", 1.0973731568e7, "1.0973732×10⁷", "m⁻¹"),
        ScientificConstant("atm", "Standard Atmosphere", "الضغط الجوي القياسي", 101325.0, "101325", "Pa")
    )
}
