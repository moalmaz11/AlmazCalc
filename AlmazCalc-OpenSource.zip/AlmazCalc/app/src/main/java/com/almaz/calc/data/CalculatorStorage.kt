package com.almaz.calc.data

import android.content.Context
import com.almaz.calc.engine.AngleUnit
import com.almaz.calc.ui.theme.CalculatorSkinId
import org.json.JSONArray
import org.json.JSONObject

data class HistoryItem(
    val id: Long,
    val expression: String,
    val result: String,
    val timestamp: Long
)

data class UserSettings(
    val skin: CalculatorSkinId = CalculatorSkinId.AMOLED_PRO,
    val language: AppLanguage = AppLanguage.ENGLISH,
    val angleUnit: AngleUnit = AngleUnit.DEG,
    val precision: Int = 10,
    val hapticEnabled: Boolean = true,
    val keepScreenOn: Boolean = false
)

class CalculatorStorage(context: Context) {
    private val prefs = context.getSharedPreferences("almaz_calc_prefs", Context.MODE_PRIVATE)

    fun loadSettings(): UserSettings {
        val skinName = prefs.getString("skin", CalculatorSkinId.AMOLED_PRO.name)
        val langCode = prefs.getString("lang", AppLanguage.ENGLISH.code)
        val angleName = prefs.getString("angle", AngleUnit.DEG.name)

        return UserSettings(
            skin = CalculatorSkinId.entries.find { it.name == skinName } ?: CalculatorSkinId.AMOLED_PRO,
            language = AppLanguage.entries.find { it.code == langCode } ?: AppLanguage.ENGLISH,
            angleUnit = AngleUnit.entries.find { it.name == angleName } ?: AngleUnit.DEG,
            precision = prefs.getInt("precision", 10).coerceIn(2, 12),
            hapticEnabled = prefs.getBoolean("haptic", true),
            keepScreenOn = prefs.getBoolean("keep_screen_on", false)
        )
    }

    fun saveSettings(settings: UserSettings) {
        prefs.edit()
            .putString("skin", settings.skin.name)
            .putString("lang", settings.language.code)
            .putString("angle", settings.angleUnit.name)
            .putInt("precision", settings.precision)
            .putBoolean("haptic", settings.hapticEnabled)
            .putBoolean("keep_screen_on", settings.keepScreenOn)
            .apply()
    }

    fun loadHistory(): List<HistoryItem> {
        val raw = prefs.getString("history_json", "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    add(
                        HistoryItem(
                            id = obj.optLong("id", i.toLong()),
                            expression = obj.optString("expr", ""),
                            result = obj.optString("res", ""),
                            timestamp = obj.optLong("ts", 0L)
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveHistory(items: List<HistoryItem>) {
        val arr = JSONArray()
        items.take(100).forEach { item ->
            arr.put(
                JSONObject().apply {
                    put("id", item.id)
                    put("expr", item.expression)
                    put("res", item.result)
                    put("ts", item.timestamp)
                }
            )
        }
        prefs.edit().putString("history_json", arr.toString()).apply()
    }

    fun loadVariables(): Map<String, Double> {
        val raw = prefs.getString("vars_json", "{}") ?: "{}"
        return try {
            val obj = JSONObject(raw)
            val map = mutableMapOf<String, Double>()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                map[k] = obj.optDouble(k, 0.0)
            }
            map
        } catch (_: Exception) {
            emptyMap()
        }
    }

    fun saveVariables(vars: Map<String, Double>) {
        val obj = JSONObject()
        vars.forEach { (k, v) ->
            if (!v.isNaN() && !v.isInfinite()) {
                obj.put(k, v)
            }
        }
        prefs.edit().putString("vars_json", obj.toString()).apply()
    }
}
