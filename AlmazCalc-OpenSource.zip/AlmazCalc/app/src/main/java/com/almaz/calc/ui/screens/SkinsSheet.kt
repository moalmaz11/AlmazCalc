@file:OptIn(ExperimentalMaterial3Api::class)

package com.almaz.calc.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.almaz.calc.data.AppStrings
import com.almaz.calc.ui.theme.CalculatorSkinId
import com.almaz.calc.ui.theme.resolveSkinPalette

@Composable
fun SkinsBottomSheet(
    currentSkin: CalculatorSkinId,
    strings: AppStrings,
    onSelectSkin: (CalculatorSkinId) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    fun skinName(id: CalculatorSkinId): String = when (id) {
        CalculatorSkinId.AMOLED_PRO -> strings.skinAmoledPro
        CalculatorSkinId.PURE_AMOLED -> strings.skinPureAmoled
        CalculatorSkinId.SLATE_CLASSIC -> strings.skinSlateClassic
        CalculatorSkinId.MODERN_LIGHT -> strings.skinModernLight
        CalculatorSkinId.MATERIAL_YOU -> strings.skinMaterialYou
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp)
        ) {
            Text(
                text = strings.selectSkin,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp)
            )
            Spacer(modifier = Modifier.height(14.dp))

            LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(CalculatorSkinId.entries) { skinId ->
                    val previewPalette = resolveSkinPalette(skinId)
                    val isSelected = skinId == currentSkin

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .width(156.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .border(
                                width = if (isSelected) 2.5.dp else 1.dp,
                                color = if (isSelected) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.outlineVariant,
                                shape = RoundedCornerShape(18.dp)
                            )
                            .background(previewPalette.bodyBg)
                            .clickable { onSelectSkin(skinId) }
                            .padding(10.dp)
                    ) {
                        // Mini LCD preview
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(previewPalette.displayBg)
                                .padding(6.dp)
                        ) {
                            Text(
                                text = "√2/2 + π",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = previewPalette.displayPrimaryText,
                                modifier = Modifier.align(Alignment.TopStart)
                            )
                            Text(
                                text = "3.8487",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = previewPalette.displayPrimaryText,
                                modifier = Modifier.align(Alignment.BottomEnd)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Mini SHIFT / ALPHA / D-Pad row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(16.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(previewPalette.shiftKeyBg)
                            )
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(16.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(previewPalette.alphaKeyBg)
                            )
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .clip(CircleShape)
                                    .background(previewPalette.dpadOuterBg)
                            )
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(16.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(previewPalette.sciKeyBg)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Mini Keypad grid preview
                        repeat(3) { rowIdx ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                repeat(4) { colIdx ->
                                    val color = when {
                                        rowIdx == 0 && colIdx == 3 -> previewPalette.delAcKeyBg
                                        rowIdx == 2 && colIdx == 3 -> previewPalette.equalsKeyBg
                                        colIdx == 3 -> previewPalette.opKeyBg
                                        rowIdx == 0 -> previewPalette.sciKeyBg
                                        else -> previewPalette.numKeyBg
                                    }
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(15.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(color)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Rounded.Check,
                                    contentDescription = null,
                                    tint = previewPalette.accentColor,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                            Text(
                                text = skinName(skinId),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (previewPalette.isDarkBody)
                                    androidx.compose.ui.graphics.Color.White
                                else
                                    androidx.compose.ui.graphics.Color(0xFF1A2026)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.select)
                }

                OutlinedButton(
                    onClick = {
                        val other = CalculatorSkinId.entries.filter { it != currentSkin }
                        onSelectSkin(other.random())
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.Shuffle, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.random)
                }
            }
        }
    }
}
