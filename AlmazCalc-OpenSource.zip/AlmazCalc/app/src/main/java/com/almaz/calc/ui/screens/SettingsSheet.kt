@file:OptIn(ExperimentalMaterial3Api::class)

package com.almaz.calc.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.almaz.calc.data.AppLanguage
import com.almaz.calc.data.AppStrings
import com.almaz.calc.data.UserSettings
import com.almaz.calc.engine.AngleUnit
import kotlin.math.roundToInt

@Composable
fun SettingsBottomSheet(
    settings: UserSettings,
    strings: AppStrings,
    onLanguageChange: (AppLanguage) -> Unit,
    onAngleUnitChange: (AngleUnit) -> Unit,
    onPrecisionChange: (Int) -> Unit,
    onHapticChange: (Boolean) -> Unit,
    onKeepScreenOnChange: (Boolean) -> Unit,
    onOpenSkins: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = strings.settings,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )

            // Language selector
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(strings.language, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    AppLanguage.entries.forEach { lang ->
                        FilterChip(
                            selected = settings.language == lang,
                            onClick = { onLanguageChange(lang) },
                            label = { Text(lang.displayName) }
                        )
                    }
                }
            }

            // Skin quick entry
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(strings.skins, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                TextButton(onClick = {
                    onDismiss()
                    onOpenSkins()
                }) {
                    Text(strings.selectSkin)
                }
            }

            // Default Angle Unit
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(strings.angleUnit, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    AngleUnit.entries.forEach { unit ->
                        FilterChip(
                            selected = settings.angleUnit == unit,
                            onClick = { onAngleUnitChange(unit) },
                            label = { Text(unit.label) }
                        )
                    }
                }
            }

            // Decimal Precision Slider
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(strings.decimalPrecision, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text("${settings.precision}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
                Slider(
                    value = settings.precision.toFloat(),
                    onValueChange = { onPrecisionChange(it.roundToInt()) },
                    valueRange = 2f..12f,
                    steps = 9
                )
            }

            HorizontalDivider()

            // Haptic feedback toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(strings.hapticFeedback, style = MaterialTheme.typography.bodyLarge)
                Switch(
                    checked = settings.hapticEnabled,
                    onCheckedChange = onHapticChange
                )
            }

            // Keep screen on toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(strings.keepScreenOn, style = MaterialTheme.typography.bodyLarge)
                Switch(
                    checked = settings.keepScreenOn,
                    onCheckedChange = onKeepScreenOnChange
                )
            }

            HorizontalDivider()

            // About & Attribution Card
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = strings.appTitle,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${strings.versionLabel} • ${strings.openSourceLicense}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = strings.offlineBadge,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Made with love by Mostafa Almaz 🤍",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}
