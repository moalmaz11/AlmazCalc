package com.almaz.calc.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.almaz.calc.ui.theme.CalculatorSkinPalette
import com.almaz.calc.viewmodel.CalculatorUiState
import com.almaz.calc.viewmodel.DisplayFormatMode

@Composable
fun CalculatorDisplay(
    state: CalculatorUiState,
    palette: CalculatorSkinPalette,
    modifier: Modifier = Modifier
) {
    val exprScroll = rememberScrollState()
    LaunchedEffect(state.expression, state.cursorIndex) {
        exprScroll.scrollTo(exprScroll.maxValue)
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(
            modifier = modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(palette.displayBg)
                .border(1.5.dp, palette.displayBorder, RoundedCornerShape(14.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Casio-style top status indicators strip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusBadge("S", active = state.isShift, palette = palette)
                StatusBadge("A", active = state.isAlpha, palette = palette)
                StatusBadge("STO", active = state.isStoPending, palette = palette)
                StatusBadge("RCL", active = state.isRclPending, palette = palette)
                StatusBadge("HYP", active = state.isHyp, palette = palette)
                StatusBadge(
                    "M",
                    active = (state.variables["M"] ?: 0.0) != 0.0,
                    palette = palette
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = state.settings.angleUnit.label,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = palette.displayStatusText
                )
                Text(
                    text = "MATH",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace,
                    color = palette.displayStatusText.copy(alpha = 0.8f)
                )
                val fmtLabel = when (state.formatMode) {
                    DisplayFormatMode.DECIMAL -> "DECI"
                    DisplayFormatMode.FRACTION -> "FRAC"
                    DisplayFormatMode.ENGINEERING -> "ENG"
                    DisplayFormatMode.DMS -> "DMS"
                    DisplayFormatMode.PRIME_FACTOR -> "FACT"
                }
                Text(
                    text = fmtLabel,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace,
                    color = palette.displayStatusText.copy(alpha = 0.8f)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Expression input row with visible cursor bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(exprScroll),
                contentAlignment = Alignment.CenterStart
            ) {
                val safeCursor = state.cursorIndex.coerceIn(0, state.expression.length)
                val annotated = buildAnnotatedString {
                    if (state.expression.isEmpty()) {
                        withStyle(SpanStyle(color = palette.cursorColor, fontWeight = FontWeight.Bold)) {
                            append("│")
                        }
                    } else {
                        append(state.expression.substring(0, safeCursor))
                        if (!state.justEvaluated) {
                            withStyle(SpanStyle(color = palette.cursorColor, fontWeight = FontWeight.Bold)) {
                                append("│")
                            }
                        }
                        append(state.expression.substring(safeCursor))
                    }
                }
                Text(
                    text = annotated,
                    fontSize = if (state.expression.length > 22) 20.sp else 26.sp,
                    lineHeight = 30.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Medium,
                    color = palette.displayPrimaryText,
                    maxLines = 2
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Result row (Live preview while typing, bold final result after =)
            val displayedResult = when {
                state.isError -> state.finalResult
                state.justEvaluated && state.finalResult.isNotEmpty() -> state.finalResult
                state.liveResult.isNotEmpty() -> state.liveResult
                else -> "0"
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = displayedResult,
                    fontSize = when {
                        state.isError -> 20.sp
                        state.justEvaluated -> 30.sp
                        else -> 24.sp
                    },
                    fontFamily = FontFamily.Monospace,
                    fontWeight = if (state.justEvaluated) FontWeight.Bold else FontWeight.Medium,
                    color = when {
                        state.isError -> palette.alphaKeyBg
                        state.justEvaluated -> palette.displayPrimaryText
                        else -> palette.displaySecondaryText
                    },
                    textAlign = TextAlign.End,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun StatusBadge(
    label: String,
    active: Boolean,
    palette: CalculatorSkinPalette
) {
    if (active) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(palette.displayPrimaryText)
                .padding(horizontal = 4.dp, vertical = 1.dp)
        ) {
            Text(
                text = label,
                fontSize = 9.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace,
                color = palette.displayBg
            )
        }
    } else {
        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = FontWeight.Medium,
            fontFamily = FontFamily.Monospace,
            color = palette.displayStatusText.copy(alpha = 0.28f)
        )
    }
}
