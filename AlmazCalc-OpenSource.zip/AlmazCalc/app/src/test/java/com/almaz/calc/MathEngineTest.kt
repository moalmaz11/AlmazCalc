package com.almaz.calc

import com.almaz.calc.engine.AngleUnit
import com.almaz.calc.engine.EvalResult
import com.almaz.calc.engine.MathEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MathEngineTest {

    private fun eval(expr: String, unit: AngleUnit = AngleUnit.DEG): Double {
        val result = MathEngine.evaluate(expr, unit)
        assertTrue("Expected success for '$expr', got $result", result is EvalResult.Success)
        return (result as EvalResult.Success).value
    }

    @Test
    fun testBasicAndPrecedence() {
        assertEquals(14.0, eval("2+3×4"), 1e-9)
        assertEquals(20.0, eval("(2+3)×4"), 1e-9)
        assertEquals(512.0, eval("2^3^2"), 1e-9)
        assertEquals(120.0, eval("5!"), 1e-9)
    }

    @Test
    fun testImplicitMultiplicationAndRoots() {
        assertEquals(6.283185307179586, eval("2π"), 1e-9)
        assertEquals(6.0, eval("2√(9)"), 1e-9)
        assertEquals(3.0, eval("∛(27)"), 1e-9)
    }

    @Test
    fun testTrigonometry() {
        assertEquals(0.5, eval("sin(30)", AngleUnit.DEG), 1e-9)
        assertEquals(1.0, eval("sin(π/2)", AngleUnit.RAD), 1e-9)
        assertEquals(1.0, eval("sin(100)", AngleUnit.GRAD), 1e-9)
        assertEquals(45.0, eval("tan⁻¹(1)", AngleUnit.DEG), 1e-9)
    }

    @Test
    fun testCalculusAndSolver() {
        // d/dx of x^2 at x = 3 is 6
        assertEquals(6.0, eval("d/dx(x^2, 3)"), 1e-4)
        // integral of x^2 from 0 to 3 is 9
        assertEquals(9.0, eval("∫(x^2, 0, 3)"), 1e-4)
        // sum of k from 1 to 10 is 55
        assertEquals(55.0, eval("Σ(x, 1, 10)"), 1e-9)
        // solve x^2 - 9 = 0 near positive guess
        val solved = MathEngine.solveEquation("x^2-9=0", 2.0)
        assertTrue(solved is EvalResult.Success)
        assertEquals(3.0, (solved as EvalResult.Success).value, 1e-6)
    }

    @Test
    fun testCombinatoricsAndFormatting() {
        assertEquals(60.0, eval("nPr(5,3)"), 1e-9)
        assertEquals(10.0, eval("nCr(5,3)"), 1e-9)
        assertEquals(6.0, eval("gcd(18,24)"), 1e-9)
        assertEquals(72.0, eval("lcm(18,24)"), 1e-9)
        assertEquals("3/4", MathEngine.toExactFraction(0.75))
        assertEquals("2³ × 3² × 5", MathEngine.primeFactorize(360.0))
    }
}
